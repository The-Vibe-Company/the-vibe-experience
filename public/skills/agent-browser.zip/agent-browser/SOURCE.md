# Source

Ce paquet reprend le skill « agent-browser » de Vercel Labs, tel quel.

- Dépôt : https://github.com/vercel-labs/agent-browser
- Licence : Apache-2.0 (voir LICENSE)

Ce SKILL.md est un stub de découverte : au premier usage, agent-browser installe
son outil en ligne de commande (`npm i -g agent-browser && agent-browser install`).
Claude Code s'en charge tout seul quand tu lui demandes de tester ton site.
Rien n'a été modifié au contenu du skill.
