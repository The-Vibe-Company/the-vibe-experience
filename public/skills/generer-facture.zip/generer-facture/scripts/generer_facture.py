#!/usr/bin/env python3
"""Générateur de factures : transforme la configuration de l'entreprise + les
données de la facture du jour en un fichier HTML A4 prêt à imprimer en PDF.

Usage :
  python3 generer_facture.py --config <config/entreprise.json> --facture <facture.json>
                             [--sortie <dossier>] [--enregistrer]

Trois types de factures (champ "type" du fichier de facture) :
  - "complete" : facture classique, toutes les lignes.
  - "acompte"  : facture d'acompte (pourcentage ou montant, sur une base donnée,
                 typiquement un devis accepté).
  - "solde"    : facture finale qui reprend toutes les lignes et DÉDUIT les
                 acomptes déjà facturés (net à payer).

Le script est volontairement en Python standard, sans aucune dépendance.
Tous les calculs (totaux, TVA, prorata d'acompte, déductions, échéance) sont
faits ici et seulement ici : l'agent ne calcule jamais un montant à la main.
"""

import argparse
import base64
import datetime
import html
import json
import mimetypes
import os
import re
import sys
import unicodedata

MOIS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
           "août", "septembre", "octobre", "novembre", "décembre"]

MENTION_FRANCHISE = "TVA non applicable, art. 293 B du CGI"

UNITES = ["zéro", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit",
          "neuf", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize"]
DIZAINES = {20: "vingt", 30: "trente", 40: "quarante", 50: "cinquante",
            60: "soixante", 80: "quatre-vingt"}


def nombre_en_lettres(n):
    """Nombre entier en toutes lettres (orthographe rectifiée de 1990, traits
    d'union partout), pour la mention « arrêtée à la somme de »."""
    n = int(n)
    if n < 0:
        return "moins " + nombre_en_lettres(-n)
    if n < 17:
        return UNITES[n]
    if n < 20:
        return "dix-" + UNITES[n - 10]
    if n < 100:
        if n in (71, 91) or 71 < n < 80 or n > 91:
            d = 60 if n < 80 else 80
            reste = n - d
            return DIZAINES[d] + ("-et-" if reste == 11 and d == 60 else "-") + \
                (nombre_en_lettres(reste) if d == 60 else nombre_en_lettres(reste))
        d = (n // 10) * 10
        if d == 70:
            d, reste = 60, n - 60
        elif d == 90:
            d, reste = 80, n - 80
        else:
            reste = n - d
        if reste == 0:
            return DIZAINES[d] + ("s" if d == 80 else "")
        if reste == 1 and d in (20, 30, 40, 50, 60):
            return DIZAINES[d] + "-et-un"
        return DIZAINES[d] + "-" + nombre_en_lettres(reste)
    if n < 1000:
        c, reste = divmod(n, 100)
        tete = "cent" if c == 1 else nombre_en_lettres(c) + "-cent"
        if reste == 0:
            return tete + ("s" if c > 1 else "")
        return tete + "-" + nombre_en_lettres(reste)
    if n < 1_000_000:
        m, reste = divmod(n, 1000)
        tete = "mille" if m == 1 else nombre_en_lettres(m) + "-mille"
        return tete if reste == 0 else tete + "-" + nombre_en_lettres(reste)
    M, reste = divmod(n, 1_000_000)
    tete = nombre_en_lettres(M) + ("-million" if M == 1 else "-millions")
    return tete if reste == 0 else tete + "-" + nombre_en_lettres(reste)


def montant_en_lettres(valeur):
    """1234.56 -> « mille-deux-cent-trente-quatre euros et cinquante-six centimes »."""
    euros = int(valeur)
    centimes = int(round((valeur - euros) * 100))
    texte = nombre_en_lettres(euros) + (" euro" if euros in (0, 1) else " euros")
    if centimes:
        texte += " et " + nombre_en_lettres(centimes) + \
                 (" centime" if centimes == 1 else " centimes")
    return texte


def erreur(msg):
    print(f"ERREUR : {msg}", file=sys.stderr)
    sys.exit(1)


def charger_json(chemin, nom):
    if not os.path.exists(chemin):
        erreur(f"fichier {nom} introuvable : {chemin}")
    try:
        with open(chemin, encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        erreur(f"le fichier {nom} n'est pas un JSON valide ({chemin}) : {e}")


def date_fr(d):
    return f"{d.day} {MOIS_FR[d.month - 1]} {d.year}"


def parser_date(texte):
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.datetime.strptime(texte, fmt).date()
        except ValueError:
            continue
    erreur(f"date illisible : « {texte} » (formats acceptés : AAAA-MM-JJ ou JJ/MM/AAAA)")


def montant_fr(valeur):
    entier, decimales = f"{valeur:,.2f}".split(".")
    entier = entier.replace(",", " ")
    return f"{entier},{decimales} €"


def nombre_fr(valeur):
    if float(valeur) == int(float(valeur)):
        return str(int(float(valeur)))
    return f"{float(valeur):g}".replace(".", ",")


def slug(texte):
    texte = unicodedata.normalize("NFKD", texte).encode("ascii", "ignore").decode()
    texte = re.sub(r"[^A-Za-z0-9]+", "-", texte).strip("-")
    return texte or "client"


def e(texte):
    return html.escape(str(texte), quote=True)


def client_professionnel(facture):
    c = facture.get("client", {})
    if "professionnel" in c:
        return bool(c["professionnel"])
    return bool(c.get("siret") or c.get("numero_tva_intra"))


def valider(config, facture):
    manques = []
    ent = config.get("entreprise", {})
    for champ, libelle in [("nom", "le nom de l'entreprise"),
                           ("adresse_lignes", "l'adresse de l'entreprise"),
                           ("siret", "le numéro SIREN ou SIRET")]:
        if not ent.get(champ):
            manques.append(f"{libelle} (configuration, bloc « entreprise »)")

    tva = config.get("tva", {})
    if not tva.get("franchise") and tva.get("taux_defaut") is None:
        manques.append("le taux de TVA par défaut (configuration, bloc « tva ») "
                       "ou le régime de franchise en base")

    client = facture.get("client", {})
    if not client.get("nom"):
        manques.append("le nom du client (facture, bloc « client »)")
    if not client.get("adresse_lignes"):
        manques.append("l'adresse du client (facture, bloc « client »)")

    type_f = facture.get("type", "complete")
    if type_f not in ("complete", "acompte", "solde", "avoir"):
        erreur(f"type de facture inconnu : « {type_f} » "
               "(attendu : complete, acompte, solde ou avoir)")

    if type_f == "avoir":
        fi = facture.get("facture_initiale", {})
        if not fi.get("numero") or not fi.get("date"):
            manques.append("le numéro ET la date de la facture initiale (facture, bloc "
                           "« facture_initiale ») : un avoir doit référencer la facture "
                           "qu'il corrige, c'est une mention obligatoire")
        if not facture.get("lignes"):
            manques.append("au moins une ligne décrivant ce qui est crédité (facture, « lignes »)")
        for i, l in enumerate(facture.get("lignes", []), 1):
            if not l.get("description"):
                manques.append(f"la description de la ligne {i} de l'avoir")
            if l.get("prix_unitaire_ht") is None and l.get("prix_unitaire_ttc") is None:
                manques.append(f"le montant de la ligne {i} de l'avoir")

    if type_f in ("complete", "solde"):
        lignes = facture.get("lignes", [])
        if not lignes:
            manques.append("au moins une ligne (facture, « lignes »)")
        for i, l in enumerate(lignes, 1):
            if not l.get("description"):
                manques.append(f"la description de la ligne {i}")
            if l.get("prix_unitaire_ht") is None and l.get("prix_unitaire_ttc") is None:
                manques.append(f"le prix unitaire de la ligne {i} (HT ou TTC)")
        if not facture.get("date_prestation"):
            manques.append("la date (ou période) de la vente ou de la prestation "
                           "(facture, « date_prestation ») : mention obligatoire")

    if type_f == "acompte":
        a = facture.get("acompte", {})
        if a.get("pourcentage") is None and a.get("montant_ht") is None:
            manques.append("le pourcentage OU le montant HT de l'acompte (facture, bloc « acompte »)")
        if a.get("pourcentage") is not None and not a.get("base_lignes") and a.get("base_total_ht") is None:
            manques.append("la base de l'acompte : les lignes du devis (« base_lignes ») "
                           "ou son total HT (« base_total_ht »)")

    if type_f == "solde":
        for i, ac in enumerate(facture.get("acomptes_deja_factures", []), 1):
            if not ac.get("numero"):
                manques.append(f"le numéro de la facture d'acompte {i} à déduire")
            if ac.get("montant_ttc") is None and ac.get("montant_ht") is None:
                manques.append(f"le montant de la facture d'acompte {i} à déduire")

    if manques:
        erreur("la facture ne peut pas être générée, il manque :\n  - " + "\n  - ".join(manques))


def numero_facture(config, facture, date_emission):
    if facture.get("numero"):
        return str(facture["numero"]), False
    d = config.get("facture", {})
    if facture.get("type") == "avoir":
        # Les avoirs ont leur propre série (admise par le BOFiP), préfixe AV
        # par défaut, pour ne pas trouer la série des factures.
        d = d.get("avoir") or {"prefixe_numero": "AV", "prochain_numero": 1,
                               "format_numero": d.get("format_numero",
                                                      "{prefixe}-{annee}-{seq:03d}")}
    prefixe = d.get("prefixe_numero", "FA")
    seq = int(d.get("prochain_numero", 1))
    fmt = d.get("format_numero", "{prefixe}-{annee}-{seq:03d}")
    # Passage d'année : quand le format contient l'année, la série est annuelle
    # (règle BOFiP des séries distinctes) et la séquence repart à 1 au 1er
    # janvier. C'est le script qui le fait, pas l'agent, pour qu'aucune série
    # ne soit cassée par oubli. Ceux qui numérotent en continu d'une année sur
    # l'autre mettent "reset_annuel": false dans le bloc facture.
    if "{annee}" in fmt and d.get("reset_annuel", True):
        annee_serie = d.get("annee_serie")
        if annee_serie is not None and int(annee_serie) != date_emission.year:
            seq = 1
    return fmt.format(prefixe=prefixe, annee=date_emission.year, seq=seq), True


def bloc_logo(config, base_config):
    chemin = config.get("entreprise", {}).get("logo")
    if not chemin:
        return f'<div style="font-size:16pt;font-weight:700;">{e(config["entreprise"]["nom"])}</div>'
    if not os.path.isabs(chemin):
        chemin = os.path.join(os.path.dirname(base_config), chemin)
    if not os.path.exists(chemin):
        print(f"AVERTISSEMENT : logo introuvable ({chemin}), le nom de l'entreprise est "
              "affiché à la place.", file=sys.stderr)
        return f'<div style="font-size:16pt;font-weight:700;">{e(config["entreprise"]["nom"])}</div>'
    mime = mimetypes.guess_type(chemin)[0] or "image/png"
    with open(chemin, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return f'<img src="data:{mime};base64,{b64}" alt="{e(config["entreprise"]["nom"])}">'


def champ_libre_texte(cl):
    if isinstance(cl, str):
        return cl
    return f"{cl['label']} : {cl['valeur']}"


def bloc_adresse(nom, lignes, extras):
    out = [f'<div class="nom">{e(nom)}</div>']
    for ligne in lignes:
        out.append(f"<div>{e(ligne)}</div>")
    for extra in extras:
        out.append(f"<div>{e(extra)}</div>")
    return "\n".join(out)


def construire_emetteur(config):
    ent = config["entreprise"]
    nom = ent["nom"]
    if ent.get("forme_juridique"):
        nom = f"{nom} ({ent['forme_juridique']})"
    if ent.get("mention_ei"):
        nom = f"{nom} EI"
    extras = []
    if ent.get("siret"):
        extras.append(f"SIRET {ent['siret']}" if len(re.sub(r"\D", "", str(ent["siret"]))) == 14
                      else f"SIREN {ent['siret']}")
    tva = config.get("tva", {})
    if tva.get("numero_tva_intra"):
        extras.append(f"TVA intracommunautaire : {tva['numero_tva_intra']}")
    for champ, gabarit in [("telephone", "Tél. {}"), ("email", "{}"), ("site_web", "{}")]:
        if ent.get(champ):
            extras.append(gabarit.format(ent[champ]))
    for cl in config.get("champs_libres", []):
        extras.append(champ_libre_texte(cl))
    return bloc_adresse(nom, ent.get("adresse_lignes", []), extras)


def construire_client(facture):
    c = facture["client"]
    extras = []
    if c.get("siret"):
        extras.append(f"SIRET {c['siret']}")
    if c.get("numero_tva_intra"):
        extras.append(f"TVA intracommunautaire : {c['numero_tva_intra']}")
    for champ in ("email", "telephone"):
        if c.get(champ):
            extras.append(c[champ])
    if c.get("adresse_livraison_lignes"):
        extras.append("Adresse de livraison : " + ", ".join(c["adresse_livraison_lignes"]))
    for cl in c.get("champs_libres", []):
        extras.append(champ_libre_texte(cl))
    return bloc_adresse(c["nom"], c.get("adresse_lignes", []), extras)


def construire_champs_facture(facture):
    lignes = []
    if facture.get("reference_devis"):
        lignes.append(("Référence devis", facture["reference_devis"]))
    if facture.get("bon_de_commande"):
        lignes.append(("Bon de commande", facture["bon_de_commande"]))
    for cl in facture.get("champs_libres", []):
        if isinstance(cl, str):
            lignes.append((None, cl))
        else:
            lignes.append((cl["label"], cl["valeur"]))
    if not lignes:
        return ""
    interieur = "\n".join(
        f"<div>{e(v)}</div>" if l is None else f"<div><strong>{e(l)} :</strong> {e(v)}</div>"
        for l, v in lignes)
    return f'<section class="champs-facture">\n{interieur}\n</section>'


def lignes_acompte(config, facture):
    """Construit la ou les lignes d'une facture d'acompte à partir de la base
    (les lignes du devis, pour un prorata exact par taux de TVA) ou d'un montant."""
    a = facture["acompte"]
    franchise = bool(config.get("tva", {}).get("franchise"))
    taux_defaut = config.get("tva", {}).get("taux_defaut", 20)
    ref = facture.get("reference_devis", "")
    libelle_base = a.get("description") or (
        f"Acompte sur devis {ref} accepté" if ref else "Acompte sur commande")

    if a.get("montant_ht") is not None:
        taux = 0 if franchise else float(a.get("taux_tva", taux_defaut))
        return [{"description": libelle_base, "quantite": 1,
                 "prix_unitaire_ht": round(float(a["montant_ht"]), 2), "taux_tva": taux}]

    pct = float(a["pourcentage"])
    lignes = []
    if a.get("base_lignes"):
        # Prorata par taux : un acompte de 30 % porte 30 % de chaque ligne,
        # donc la TVA de l'acompte suit exactement les taux du devis. Quand la
        # ligne vient des données d'un devis, montant_ht est déjà net de sa
        # remise de ligne : on le préfère au recalcul brut. (Pour un devis
        # avec remise GLOBALE, utiliser base_total_ht = total HT après remise.)
        par_taux = {}
        for l in a["base_lignes"]:
            taux = 0 if franchise else float(l.get("taux_tva", taux_defaut))
            if l.get("montant_ht") is not None:
                montant = float(l["montant_ht"])
            else:
                montant = float(l.get("quantite", 1)) * float(l["prix_unitaire_ht"])
                if l.get("remise_pct"):
                    montant -= montant * float(l["remise_pct"]) / 100
                elif l.get("remise_montant"):
                    montant -= float(l["remise_montant"])
            par_taux[taux] = round(par_taux.get(taux, 0.0) + montant, 2)
        for taux, base_ht in sorted(par_taux.items()):
            desc = f"{libelle_base} : {nombre_fr(pct)} %"
            if len(par_taux) > 1 and not franchise:
                desc += f" (part au taux de TVA {nombre_fr(taux)} %)"
            lignes.append({"description": desc, "quantite": 1,
                           "prix_unitaire_ht": round(base_ht * pct / 100, 2),
                           "taux_tva": taux})
    else:
        base_ht = float(a["base_total_ht"])
        taux = 0 if franchise else float(a.get("taux_tva", taux_defaut))
        lignes.append({"description": f"{libelle_base} : {nombre_fr(pct)} %", "quantite": 1,
                       "prix_unitaire_ht": round(base_ht * pct / 100, 2), "taux_tva": taux})
    return lignes


def calculer(config, lignes_source, remise_globale=None, sans_tva=False):
    """Totaux HT/TVA/TTC avec remises. Les remises par ligne (remise_pct ou
    remise_montant) s'appliquent au montant de la ligne ; la remise globale
    ({libelle, pourcentage} ou {libelle, montant_ht}) se répartit au prorata
    des taux de TVA, et la TVA se calcule TOUJOURS sur le net après remise
    (règle des réductions acquises, art. 242 nonies A)."""
    franchise = bool(config.get("tva", {}).get("franchise")) or sans_tva
    taux_defaut = config.get("tva", {}).get("taux_defaut", 20)
    brut_par_taux = {}
    lignes_calc = []
    for l in lignes_source:
        qte = float(l.get("quantite", 1))
        taux = 0 if franchise else float(l.get("taux_tva", taux_defaut))
        if l.get("prix_unitaire_ht") is not None:
            pu = float(l["prix_unitaire_ht"])
        else:
            # Prix annoncé en TTC : la conversion vers le HT se fait ICI, jamais
            # de tête par l'agent (en franchise, TTC = HT, le taux vaut 0).
            pu = round(float(l["prix_unitaire_ttc"]) / (1 + taux / 100), 2)
        brut = round(qte * pu, 2)
        remise = 0.0
        if l.get("remise_pct"):
            remise = round(brut * float(l["remise_pct"]) / 100, 2)
        elif l.get("remise_montant"):
            remise = round(float(l["remise_montant"]), 2)
        montant = round(brut - remise, 2)
        brut_par_taux[taux] = round(brut_par_taux.get(taux, 0.0) + montant, 2)
        lignes_calc.append({**l, "quantite": qte, "prix_unitaire_ht": pu,
                            "montant_brut_ht": brut, "remise_ht": remise,
                            "montant_ht": montant, "taux_tva": taux})
    total_avant_remise = round(sum(brut_par_taux.values()), 2)
    remise_g = 0.0
    libelle_remise = ""
    if remise_globale and total_avant_remise > 0:
        libelle_remise = remise_globale.get("libelle", "Remise")
        if remise_globale.get("pourcentage") is not None:
            remise_g = round(total_avant_remise * float(remise_globale["pourcentage"]) / 100, 2)
            libelle_remise += f" ({nombre_fr(remise_globale['pourcentage'])} %)"
        else:
            remise_g = round(float(remise_globale["montant_ht"]), 2)
        # Répartition au prorata des taux pour que la TVA porte sur le net.
        restant = remise_g
        taux_tries = sorted(brut_par_taux)
        for i, taux in enumerate(taux_tries):
            part = restant if i == len(taux_tries) - 1 else \
                round(remise_g * brut_par_taux[taux] / total_avant_remise, 2)
            brut_par_taux[taux] = round(brut_par_taux[taux] - part, 2)
            restant = round(restant - part, 2)
    total_ht = round(sum(brut_par_taux.values()), 2)
    tva_par_taux = {}
    if not franchise:
        for taux, base in brut_par_taux.items():
            if taux:
                tva_par_taux[taux] = round(base * taux / 100, 2)
    total_tva = round(sum(tva_par_taux.values()), 2)
    total_ttc = round(total_ht + total_tva, 2)
    return {"franchise": franchise, "lignes": lignes_calc, "total_ht": total_ht,
            "total_ht_avant_remise": total_avant_remise, "remise_globale_ht": remise_g,
            "libelle_remise": libelle_remise,
            "tva_par_taux": tva_par_taux, "total_tva": total_tva, "total_ttc": total_ttc}


def construire_tableau(calc):
    franchise = calc["franchise"]
    plusieurs_taux = len(calc["tva_par_taux"]) > 1
    entetes = ["<th>Désignation</th>", '<th class="num">Qté</th>', '<th class="num">PU HT</th>']
    if plusieurs_taux:
        entetes.append('<th class="num">TVA</th>')
    entetes.append('<th class="num">Total HT</th>')
    rangs = []
    for l in calc["lignes"]:
        titre = l["description"]
        if l.get("reference"):
            titre = f"{titre} (réf. {l['reference']})"
        desc = f"<strong>{e(titre)}</strong>"
        if l.get("details"):
            desc += f'<div class="desc-details">{e(l["details"])}</div>'
        qte = nombre_fr(l["quantite"])
        if l.get("unite"):
            unite = l["unite"]
            if l["quantite"] > 1 and len(unite) > 2 and unite[-1].isalpha() \
               and unite[-1] not in "sxz":
                unite += "s"
            qte += f" {e(unite)}"
        if l.get("remise_ht"):
            detail_remise = f"Remise : -{montant_fr(l['remise_ht'])}"
            if l.get("remise_pct"):
                detail_remise += f" ({nombre_fr(l['remise_pct'])} %)"
            desc += f'<div class="desc-details">{e(detail_remise)}</div>'
        cellules = [f"<td>{desc}</td>", f'<td class="num">{qte}</td>',
                    f'<td class="num">{montant_fr(l["prix_unitaire_ht"])}</td>']
        if plusieurs_taux:
            cellules.append(f'<td class="num">{nombre_fr(l["taux_tva"])} %</td>')
        cellules.append(f'<td class="num">{montant_fr(l["montant_ht"])}</td>')
        rangs.append("<tr>" + "".join(cellules) + "</tr>")
    return "".join(entetes), "\n".join(rangs)


def montant_ttc_acompte(ac):
    if ac.get("montant_ttc") is not None:
        return round(float(ac["montant_ttc"]), 2)
    return round(float(ac["montant_ht"]), 2)


def construire_totaux(calc, facture):
    rangs = []
    if calc.get("remise_globale_ht"):
        rangs.append(f"<tr><td>Total HT avant remise</td>"
                     f"<td>{montant_fr(calc['total_ht_avant_remise'])}</td></tr>")
        rangs.append(f'<tr class="deduction"><td>{e(calc["libelle_remise"])}</td>'
                     f"<td>-{montant_fr(calc['remise_globale_ht'])}</td></tr>")
    rangs.append(f"<tr><td>Total HT</td><td>{montant_fr(calc['total_ht'])}</td></tr>")
    if not calc["franchise"]:
        for taux in sorted(calc["tva_par_taux"]):
            rangs.append(f"<tr><td>TVA {nombre_fr(taux)} %</td>"
                         f"<td>{montant_fr(calc['tva_par_taux'][taux])}</td></tr>")
        rangs.append(f"<tr><td>Total TTC</td><td>{montant_fr(calc['total_ttc'])}</td></tr>")
    deja = facture.get("acomptes_deja_factures", []) if facture.get("type") == "solde" else []
    net = calc["total_ht"] if calc["franchise"] else calc["total_ttc"]
    for ac in deja:
        m = montant_ttc_acompte(ac)
        net = round(net - m, 2)
        rangs.append(f'<tr class="deduction"><td>Acompte déjà facturé '
                     f"({e(ac['numero'])})</td><td>-{montant_fr(m)}</td></tr>")
    libelle = "Total de l'avoir (à votre crédit)" if facture.get("type") == "avoir" \
        else "Net à payer"
    rangs.append(f'<tr class="total-final"><td>{libelle}</td><td>{montant_fr(net)}</td></tr>')
    return "\n".join(rangs), net


def construire_mentions(config, facture, calc, date_echeance, net_a_payer):
    f_cfg = config.get("facture", {})
    pro = client_professionnel(facture)
    type_f = facture.get("type", "complete")
    mentions = []
    if type_f == "avoir":
        fi = facture["facture_initiale"]
        mentions.append(f"Avoir sur la facture {fi['numero']} du {fi['date']}.")
        if facture.get("net_de_taxe"):
            mentions.append("Avoir net de taxe : la TVA de la facture initiale "
                            "n'est pas régularisée.")
    if config.get("tva", {}).get("franchise"):
        mentions.append(MENTION_FRANCHISE + ".")
    if config.get("tva", {}).get("option_debits"):
        mentions.append("Option pour le paiement de la taxe d'après les débits.")
    if facture.get("nature_operation"):
        mentions.append(f"Nature de l'opération : {facture['nature_operation']}.")
    if f_cfg.get("montant_en_lettres", True):
        doc = "Avoir arrêté" if type_f == "avoir" else "Facture arrêtée"
        mentions.append(f"{doc} à la somme de {montant_en_lettres(abs(net_a_payer))}.")
    if type_f == "avoir":
        mentions.append("Montant à valoir sur vos prochains règlements, ou remboursé "
                        "sur demande.")
    else:
        modes = f_cfg.get("modes_paiement", "virement bancaire")
        mentions.append(f"Règlement : {modes}, au plus tard le {date_fr(date_echeance)}.")
    if f_cfg.get("iban") and type_f != "avoir":
        mentions.append(f"IBAN : {f_cfg['iban']}.")
    if pro and type_f != "avoir":
        penalites = f_cfg.get("penalites") or (
            "taux d'intérêt appliqué par la BCE à sa dernière opération de "
            "refinancement, majoré de 10 points")
        mentions.append(f"Pénalités de retard : {penalites}. "
                        "Indemnité forfaitaire pour frais de recouvrement en cas de retard "
                        "de paiement : 40 €.")
        # « néant » est la formulation validée par la fiche officielle F31808.
        mentions.append(f_cfg.get("escompte") or "Escompte pour paiement anticipé : néant.")
    ass = config.get("assurance", {})
    if ass.get("obligatoire") and ass.get("nom_assureur"):
        # L132-1 du code de l'artisanat : la mention d'assurance professionnelle
        # est due sur chaque devis ET chaque facture.
        texte = (f"Assurance {ass.get('type', 'de responsabilité décennale')} souscrite auprès de "
                 f"{ass['nom_assureur']}")
        if ass.get("coordonnees_assureur"):
            texte += f" ({ass['coordonnees_assureur']})"
        if ass.get("couverture_geographique"):
            texte += f", couverture géographique : {ass['couverture_geographique']}"
        mentions.append(texte + ".")
    if facture.get("type") == "acompte":
        mentions.append("Facture d'acompte : le solde fera l'objet d'une facture finale "
                        "après exécution.")
    for m in f_cfg.get("mentions_libres", []):
        mentions.append(m)
    for m in facture.get("mentions_libres", []):
        mentions.append(m)
    return "\n".join(f"<p>{e(m)}</p>" for m in mentions)


def construire_pied(config):
    ent = config["entreprise"]
    morceaux = [ent["nom"]]
    if ent.get("forme_juridique"):
        morceaux[-1] += f" — {ent['forme_juridique']}"
    if ent.get("mention_ei"):
        morceaux[-1] += " EI"
    if ent.get("capital_social"):
        morceaux.append(f"Capital social : {ent['capital_social']}")
    if ent.get("siret"):
        morceaux.append(f"SIRET {ent['siret']}")
    if ent.get("rcs_ou_rm"):
        morceaux.append(ent["rcs_ou_rm"])
    tva = config.get("tva", {})
    if tva.get("numero_tva_intra"):
        morceaux.append(f"TVA intracommunautaire : {tva['numero_tva_intra']}")
    return e(" · ".join(morceaux)).replace(" — ", " - ")


def main():
    p = argparse.ArgumentParser(description="Génère une facture HTML prête à imprimer en PDF.")
    p.add_argument("--config", required=True)
    p.add_argument("--facture", required=True)
    p.add_argument("--sortie", default="Factures")
    p.add_argument("--enregistrer", action="store_true",
                   help="incrémente le compteur et mémorise le client dans le carnet")
    args = p.parse_args()

    config = charger_json(args.config, "de configuration")
    facture = charger_json(args.facture, "de la facture")
    valider(config, facture)

    type_f = facture.get("type", "complete")
    date_emission = parser_date(facture["date"]) if facture.get("date") else datetime.date.today()
    # Délai de paiement : la préférence du CLIENT (fiche du carnet) prime sur
    # le défaut de la configuration.
    delai = int(facture.get("client", {}).get("delai_paiement_jours")
                or config.get("facture", {}).get("delai_paiement_jours", 30))
    if facture.get("date_echeance"):
        date_echeance = parser_date(facture["date_echeance"])
    else:
        date_echeance = date_emission + datetime.timedelta(days=delai)
    numero, numero_auto = numero_facture(config, facture, date_emission)

    lignes_source = lignes_acompte(config, facture) if type_f == "acompte" else facture["lignes"]
    calc = calculer(config, lignes_source, remise_globale=facture.get("remise"),
                    sans_tva=bool(facture.get("net_de_taxe")))
    entetes, rangs = construire_tableau(calc)
    rangs_totaux, net_a_payer = construire_totaux(calc, facture)

    titres = {"complete": "FACTURE", "acompte": "FACTURE D'ACOMPTE",
              "solde": "FACTURE DE SOLDE", "avoir": "AVOIR"}
    ligne_prestation = ""
    if facture.get("date_prestation"):
        ligne_prestation = (f"<div>Prestation ou vente : "
                            f"{e(facture['date_prestation'])}</div>")

    modele_chemin = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "..", "assets", "modele-facture.html")
    with open(modele_chemin, encoding="utf-8") as f:
        page = f.read()

    nom_doc = "Avoir" if type_f == "avoir" else "Facture"
    if type_f == "avoir":
        ligne_echeance = "<div>À valoir sur vos prochains règlements</div>"
    else:
        ligne_echeance = f"<div>À régler avant le {e(date_fr(date_echeance))}</div>"
    remplacements = {
        "{{TITRE_DOCUMENT}}": e(f"{nom_doc} {numero} — {facture['client']['nom']}"),
        "{{TITRE_FACTURE}}": titres[type_f],
        "{{BLOC_LOGO}}": bloc_logo(config, args.config),
        "{{NUMERO}}": e(numero),
        "{{DATE_EMISSION}}": e(date_fr(date_emission)),
        "{{LIGNE_DATE_PRESTATION}}": ligne_prestation,
        "{{LIGNE_ECHEANCE}}": ligne_echeance,
        "{{BLOC_EMETTEUR}}": construire_emetteur(config),
        "{{BLOC_CLIENT}}": construire_client(facture),
        "{{BLOC_CHAMPS_FACTURE}}": construire_champs_facture(facture),
        "{{ENTETES_COLONNES}}": entetes,
        "{{LIGNES_TABLEAU}}": rangs,
        "{{LIGNES_TOTAUX}}": rangs_totaux,
        "{{BLOC_MENTIONS}}": construire_mentions(config, facture, calc, date_echeance,
                                                 net_a_payer),
        "{{PIED_DE_PAGE}}": construire_pied(config),
    }
    for cle, valeur in remplacements.items():
        page = page.replace(cle, valeur)

    os.makedirs(args.sortie, exist_ok=True)
    nom_fichier = f"{nom_doc}-{slug(numero)}-{slug(facture['client']['nom'])}.html"
    chemin_sortie = os.path.join(args.sortie, nom_fichier)
    with open(chemin_sortie, "w", encoding="utf-8") as f:
        f.write(page)

    # Données à côté de la facture (même usage que le sidecar du devis :
    # permettre à une facture de solde de déduire les acomptes sans ressaisie).
    donnees = {
        "type": f"facture_{type_f}",
        "genere_par": "generer-facture",
        "numero": numero,
        "date_emission": date_emission.isoformat(),
        "date_echeance": date_echeance.isoformat(),
        "reference_devis": facture.get("reference_devis", ""),
        "client": facture["client"],
        "lignes": calc["lignes"],
        "totaux": {
            "total_ht": calc["total_ht"],
            "tva_par_taux": {str(k): v for k, v in calc["tva_par_taux"].items()},
            "total_tva": calc["total_tva"],
            "total_ttc": calc["total_ttc"],
            "franchise_tva": calc["franchise"],
            "net_a_payer": net_a_payer,
        },
        "acomptes_deduits": facture.get("acomptes_deja_factures", []),
    }
    with open(chemin_sortie[:-5] + ".json", "w", encoding="utf-8") as f:
        json.dump(donnees, f, ensure_ascii=False, indent=2)

    if args.enregistrer:
        if numero_auto:
            if type_f == "avoir":
                # Série des avoirs : compteur dédié, créé au premier avoir.
                d = config.setdefault("facture", {}).setdefault(
                    "avoir", {"prefixe_numero": "AV", "prochain_numero": 1,
                              "format_numero": config["facture"].get(
                                  "format_numero", "{prefixe}-{annee}-{seq:03d}")})
                d["prochain_numero"] = int(d.get("prochain_numero", 1)) + 1
            else:
                d = config.setdefault("facture", {})
                fmt = d.get("format_numero", "{prefixe}-{annee}-{seq:03d}")
                if "{annee}" in fmt and d.get("reset_annuel", True) and \
                   d.get("annee_serie") is not None and \
                   int(d["annee_serie"]) != date_emission.year:
                    d["prochain_numero"] = 2  # la 001 vient d'être émise
                else:
                    d["prochain_numero"] = int(d.get("prochain_numero", 1)) + 1
                d["annee_serie"] = date_emission.year
            with open(args.config, "w", encoding="utf-8") as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
        carnet_chemin = os.path.join(os.path.dirname(os.path.abspath(args.config)), "clients.json")
        carnet = {"clients": []}
        if os.path.exists(carnet_chemin):
            with open(carnet_chemin, encoding="utf-8") as f:
                carnet = json.load(f)
        c = facture["client"]
        deja = next((x for x in carnet["clients"]
                     if x["nom"].strip().lower() == c["nom"].strip().lower()), None)
        if deja:
            deja.update(c)
        else:
            carnet["clients"].append(c)
        with open(carnet_chemin, "w", encoding="utf-8") as f:
            json.dump(carnet, f, ensure_ascii=False, indent=2)

        # Catalogue des prestations : même mécanisme que le carnet clients,
        # partagé dans l'esprit avec le skill devis (même format de fichier).
        # Les lignes d'acompte/solde purement techniques (déductions) ne sont
        # pas des prestations : on ne mémorise que les factures complètes et
        # les lignes de solde (qui reprennent les vraies prestations).
        if type_f in ("complete", "solde"):
            cat_chemin = os.path.join(os.path.dirname(os.path.abspath(args.config)),
                                      "catalogue.json")
            catalogue = {"prestations": []}
            if os.path.exists(cat_chemin):
                with open(cat_chemin, encoding="utf-8") as f:
                    catalogue = json.load(f)

            def meme_fiche(fiche, ligne):
                if fiche.get("reference") and ligne.get("reference"):
                    return fiche["reference"].strip().lower() == ligne["reference"].strip().lower()
                return fiche["designation"].strip().lower() == ligne["description"].strip().lower()

            for l in calc["lignes"]:
                fiche = {"reference": l.get("reference"), "designation": l["description"],
                         "details": l.get("details", ""), "unite": l.get("unite", ""),
                         "prix_unitaire_ht": l["prix_unitaire_ht"], "taux_tva": l["taux_tva"]}
                deja = next((x for x in catalogue["prestations"] if meme_fiche(x, l)), None)
                if deja:
                    deja.update(fiche)
                else:
                    catalogue["prestations"].append(fiche)
            with open(cat_chemin, "w", encoding="utf-8") as f:
                json.dump(catalogue, f, ensure_ascii=False, indent=2)

    recap = {
        "fichier": chemin_sortie,
        "type": type_f,
        "numero": numero,
        "date": date_fr(date_emission),
        "echeance": date_fr(date_echeance),
        "total_ht": montant_fr(calc["total_ht"]),
        "total_tva": montant_fr(calc["total_tva"]) if not calc["franchise"] else "franchise de TVA",
        "total_ttc": montant_fr(calc["total_ttc"]),
        "net_a_payer": montant_fr(net_a_payer),
        "compteur_mis_a_jour": bool(args.enregistrer and numero_auto),
    }
    print(json.dumps(recap, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
