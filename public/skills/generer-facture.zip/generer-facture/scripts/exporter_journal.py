#!/usr/bin/env python3
"""Exporte le journal des factures en CSV pour le comptable.

Usage :
  python3 exporter_journal.py --factures <dossier Factures> [--sortie journal.csv]

Le script lit les fichiers de données écrits par generer_facture.py à côté de
chaque facture (mêmes noms, extension .json), et produit un CSV lisible par
Excel en français : séparateur point-virgule, virgule décimale, montants sans
symbole. Les avoirs apparaissent en négatif dans la colonne « net », pour que
la somme de la colonne donne le chiffre réellement facturé.

Aucune dépendance : Python standard uniquement.
"""

import argparse
import csv
import glob
import json
import os
import sys

TYPES = {"facture_complete": "Facture", "facture_acompte": "Facture d'acompte",
         "facture_solde": "Facture de solde", "facture_avoir": "Avoir"}


def montant_csv(valeur):
    return f"{valeur:.2f}".replace(".", ",")


def main():
    p = argparse.ArgumentParser(description="Journal des factures en CSV pour le comptable.")
    p.add_argument("--factures", required=True, help="dossier contenant les factures générées")
    p.add_argument("--sortie", default="journal-factures.csv")
    args = p.parse_args()

    lignes = []
    for chemin in glob.glob(os.path.join(args.factures, "*.json")):
        try:
            with open(chemin, encoding="utf-8") as f:
                d = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue
        if d.get("genere_par") != "generer-facture":
            continue
        t = d.get("type", "")
        totaux = d.get("totaux", {})
        net = totaux.get("net_a_payer", totaux.get("total_ttc", 0))
        signe = -1 if t == "facture_avoir" else 1
        lignes.append({
            "numero": d.get("numero", ""),
            "type": TYPES.get(t, t),
            "date": d.get("date_emission", ""),
            "echeance": d.get("date_echeance", ""),
            "client": d.get("client", {}).get("nom", ""),
            "reference_devis": d.get("reference_devis", ""),
            "total_ht": signe * totaux.get("total_ht", 0),
            "total_tva": signe * totaux.get("total_tva", 0),
            "total_ttc": signe * totaux.get("total_ttc", 0),
            "net": signe * net,
            "franchise_tva": "oui" if totaux.get("franchise_tva") else "non",
        })

    if not lignes:
        print(f"ERREUR : aucune facture générée par ce skill trouvée dans {args.factures}",
              file=sys.stderr)
        sys.exit(1)

    lignes.sort(key=lambda x: (x["date"], x["numero"]))
    with open(args.sortie, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Numéro", "Type", "Date d'émission", "Échéance", "Client",
                    "Référence devis", "Total HT", "TVA", "Total TTC",
                    "Net (à payer ou à créditer)", "Franchise de TVA"])
        for l in lignes:
            w.writerow([l["numero"], l["type"], l["date"], l["echeance"], l["client"],
                        l["reference_devis"], montant_csv(l["total_ht"]),
                        montant_csv(l["total_tva"]), montant_csv(l["total_ttc"]),
                        montant_csv(l["net"]), l["franchise_tva"]])

    total_net = sum(l["net"] for l in lignes)
    print(json.dumps({"fichier": args.sortie, "factures": len(lignes),
                      "total_net": f"{total_net:.2f}".replace(".", ",") + " €"},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
