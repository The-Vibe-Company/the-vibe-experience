# La facture en droit français : ce qui est obligatoire, ce qui est usage

Référence pour répondre aux questions de l'utilisateur sans improviser.
Chaque règle est marquée LOI ou USAGE. État du droit : juillet 2026 (les
points datés sont signalés). Sources officielles en bas de page. Ne jamais
donner de conseil juridique personnalisé au-delà : renvoyer aux sources.

## Les mentions obligatoires (le socle)

Double fondement : art. L441-9 du code de commerce (commercial) et
art. 242 nonies A de l'annexe II au CGI (fiscal). LOI :

- date d'émission ; numéro unique dans une séquence chronologique CONTINUE
  et sans trou ;
- date de la vente ou de la fin de la prestation (si différente) ;
- identité complète du vendeur (nom, adresse, forme, SIREN/SIRET, RCS et
  ville pour les sociétés, mention EI pour les entrepreneurs individuels) ;
- identité et adresse du client ; adresse de facturation si différente ;
  numéro du bon de commande s'il en a établi un ;
- numéro de TVA intracommunautaire du vendeur (tolérance : factures
  jusqu'à 150 € HT) ; celui du client quand il est redevable
  (autoliquidation, intracommunautaire) ;
- désignation précise, quantités, prix unitaire HT, remises acquises ;
- taux de TVA par ligne, montant de TVA par taux, totaux HT et TTC ;
- date d'échéance du règlement ; conditions d'escompte (la formule
  consacrée quand il n'y en a pas : « Escompte pour paiement anticipé :
  néant ») ; taux des pénalités de retard ; indemnité forfaitaire de
  recouvrement de 40 € : ces quatre-là entre PROFESSIONNELS uniquement.

Selon la situation, LOI aussi : « TVA non applicable, art. 293 B du CGI »
(franchise ; alors aucun taux ni montant de TVA), « Autoliquidation »,
mention d'exonération, assurance décennale des artisans (assureur,
coordonnées, couverture : sur chaque devis ET chaque facture, art. L132-1
code de l'artisanat), garantie légale de conformité (2 ans) pour certaines
ventes de biens aux particuliers, éco-participation le cas échéant.

## Les 4 nouvelles mentions (décret 2022-1299) : pas encore, mais bientôt

LOI à venir. SIREN du client, adresse de livraison si différente, nature de
l'opération (biens / services / mixte), « Option pour le paiement de la
taxe d'après les débits ». Exigibles au calendrier de l'émission
électronique : 1er septembre 2026 pour les grandes entreprises et ETI,
1er septembre 2027 pour les PME et micro. Le script sait déjà les afficher :
les proposer, c'est prendre de l'avance licite.

## La facturation électronique (la question chaude, état au 21/07/2026)

LOI, calendrier confirmé (fiche officielle F23208 mise à jour 30/04/2026) :

- 1er septembre 2026 : TOUTES les entreprises assujetties (même les micro
  en franchise) doivent pouvoir RECEVOIR les factures électroniques, via
  une Plateforme Agréée (PA, ex-PDP).
- 1er septembre 2026 : les grandes entreprises et ETI doivent ÉMETTRE en
  électronique. 1er septembre 2027 : les PME, TPE et micro aussi.
- Le périmètre est le B2B DOMESTIQUE entre assujettis. Les clients
  PARTICULIERS (B2C) ne sont JAMAIS concernés : une facture PDF ou papier
  reste légale envers eux sans limite de date (avec e-reporting des ventes
  côté vendeur à partir de son échéance d'émission).
- L'État a abandonné la plateforme publique gratuite (annonce du
  15/10/2024) : tout passe par les PA privées (plus de 100 immatriculées,
  liste sur impots.gouv.fr). Un PDF envoyé par mail n'est PAS une facture
  électronique au sens de la réforme.
- Sanctions à partir du 1/9/2026 (LF 2026) : 50 € par facture non émise en
  électronique (plafond 15 000 €/an), 500 € par manquement e-reporting,
  tolérance pour la première infraction régularisée.

Ce que ça veut dire pour l'utilisateur de ce skill : ses factures PDF sont
valables pour tous ses clients particuliers, sans limite. Pour ses clients
professionnels : valables jusqu'au 31 août 2027 s'il est TPE/PME/micro ;
ensuite il lui faudra une plateforme agréée pour le B2B (ce skill ne
télétransmet pas). Être honnête là-dessus, jamais rassurant à tort.

## Acomptes et soldes

- LOI : TOUT acompte encaissé doit donner lieu à une facture (art. 289
  CGI). C'est précisément ce que fait le type « acompte » du script.
- LOI : depuis 2023, la TVA est exigible dès l'encaissement de l'acompte, y
  compris pour les ventes de biens : la facture d'acompte porte donc la
  TVA (sauf franchise). Le script calcule le prorata par taux.
- LOI : la facture de solde récapitule l'opération et DÉDUIT les acomptes
  déjà facturés en les référençant par leur numéro. Une facture d'acompte
  et une facture de solde sont des factures à part entière : elles
  prennent leur place dans la séquence de numérotation.

## Numérotation

LOI : séquence chronologique continue, sans trou. Des séries distinctes
sont admises (par année, par activité) avec un préfixe par série (BOFiP).
Un numéro émis ne se réutilise JAMAIS : une facture erronée déjà envoyée
s'annule ou se corrige par un AVOIR qui référence la facture initiale
(numéro et date), pas par une réémission. Les devis, eux, n'ont aucune
obligation de numérotation : c'est la facture qui est tenue à la rigueur.

## Clients particuliers (B2C)

- LOI : pour une prestation de services à un particulier, une NOTE est
  obligatoire dès 25 € TTC (remise avant paiement, double conservé 2 ans) ;
  la facture complète du skill la couvre largement. Travaux chez un
  particulier : note obligatoire aussi (art. 290 quinquies CGI).
- Les mentions B2B (pénalités, 40 €, escompte) ne s'imposent pas envers un
  particulier : le script les retire automatiquement quand le client n'est
  pas professionnel.

## Délais de paiement et pénalités (entre professionnels)

LOI : 30 jours par défaut après exécution ; 60 jours date de facture (ou
45 jours fin de mois) maximum. Pénalités par défaut : taux BCE majoré de
10 points (12,15 % au 1er semestre 2026), plancher 3 fois le taux légal ;
exigibles sans rappel. Indemnité de recouvrement : 40 € par facture en
retard. Dépassement des plafonds : amendes jusqu'à 75 000 € / 2 000 000 €.

## Sanctions sur la facture elle-même

LOI : 15 € par mention manquante ou inexacte (plafond : le quart du montant
de la facture, art. 1737 II CGI) ; défaut de facturation : 50 % du montant
(ramené à 5 % si l'opération est comptabilisée) ; amende administrative
jusqu'à 75 000 € (personne physique) / 375 000 € (personne morale) pour
manquement aux obligations de facturation (art. L441-9 II).

## Conservation, langue, divers

LOI : conserver 10 ans (code de commerce). Facture en français par
principe ; devise étrangère possible mais TVA déterminée en euros. Aucune
signature ni tampon requis. USAGE (recommandé, jamais imposé) : IBAN et
moyens de paiement, logo, référence du devis accepté, CGV jointes.

## Sources officielles

- entreprendre.service-public.gouv.fr/vosdroits/F31808 (mentions de la
  facture, mise à jour 06/11/2025)
- entreprendre.service-public.gouv.fr/vosdroits/F23208 (facturation
  électronique, mise à jour 30/04/2026) et actualité A18802 (sanctions LF
  2026)
- legifrance.gouv.fr : art. L441-9 et L441-10 code de commerce, art. 242
  nonies A annexe II CGI (version consolidée), art. 1737 CGI, art.
  R526-27 code de commerce (mention EI), décret 2022-1299
- bofip.impots.gouv.fr : BOI-TVA-DECLA-30-20-20-10 (numérotation, séries),
  BOI-TVA-DECLA-30-20-10 (délivrance, acomptes), BOI-TVA-DECLA-30-20-20-20
  (tolérances, factures ≤ 150 € HT)
- impots.gouv.fr (« je passe à la facturation électronique », liste des
  plateformes agréées)
- entreprendre.service-public.gouv.fr/vosdroits/F23211 (délais de paiement
  et pénalités), F10029 (conservation)
- arrêté n° 83-50/A du 3 octobre 1983 (note aux particuliers dès 25 €)
