# Dossier de configuration

Ce dossier est vide à l'installation : il se remplit tout seul à ta
première utilisation du skill.

- `entreprise.json` : les informations de ton entreprise et tes réglages de
  facturation (numérotation, délai de paiement, IBAN, pénalités), collectés
  une fois. Si tu utilises déjà le skill de devis, ils sont importés de
  chez lui : tu ne réponds qu'aux questions propres aux factures.
- `clients.json` : ton carnet de clients, partagé dans l'esprit avec celui
  du skill devis, enrichi à chaque facture.
- `catalogue.json` : la mémoire de tes prestations et produits (référence,
  désignation, prix, TVA), enrichie automatiquement. La prochaine fois que
  tu factures la même chose, le skill te propose la fiche au lieu de tout
  redemander ; c'est toujours toi qui confirmes le prix.
- Ton logo, si tu en as donné un.

Pour modifier quelque chose, ne touche pas à ces fichiers : dis simplement
au skill « j'ai changé de RIB » (ou autre), il s'en occupe.
