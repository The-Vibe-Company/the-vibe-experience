---
name: generer-facture
description: >-
  Génère des factures françaises conformes et numérotées, prêtes à imprimer en
  PDF : facture classique, facture d'acompte, facture de solde qui déduit les
  acomptes. Utiliser dès que l'utilisateur veut faire, créer, préparer, émettre
  ou envoyer une facture, facturer un client, transformer un devis accepté en
  facture, facturer un acompte ou un solde, ou dit simplement « facture pour
  [client] », même sans détail. Utiliser aussi quand il veut modifier ses
  informations de facturation (IBAN, délai de paiement, numérotation,
  pénalités). Si un devis créé avec le skill generer-devis existe, la facture
  s'en déduit sans aucune ressaisie. À la première utilisation, dérouler le
  setup guidé (ou importer la configuration du skill devis si elle existe) ;
  ensuite, chaque facture ne demande que le strict nécessaire du jour.
---

# Générer une facture

Ce skill transforme une demande en une phrase (« facture pour Mme Martin »,
« le devis DEV-2026-001 est accepté, facture d'acompte de 30 % ») en une
facture française conforme : mentions obligatoires, numérotation continue,
TVA ou franchise, échéance de paiement, prête à imprimer en PDF.

L'utilisateur est souvent non-technique. Parle-lui simplement, sans jargon
(jamais « JSON », « script », « sidecar » : dire « les données de ton
devis », « tes informations enregistrées »). Une question à la fois.

## Les trois règles qui ne se négocient pas

1. **Rien ne s'invente.** Une adresse, un SIRET, un montant, une date de
   prestation, un taux : si l'information manque, elle se demande. Une
   facture est un document fiscal ; une facture fausse est pire qu'un refus.
2. **Tous les calculs et tout le rendu passent par le script**
   `scripts/generer_facture.py` : totaux, TVA, prorata d'acompte, déduction
   des acomptes, échéance. Ne calcule jamais un montant toi-même.
3. **Récapituler avant de générer.** Contrairement à un devis, une facture
   émise ne se corrige pas en la régénérant : elle se rectifie par un
   avoir. Donc le récapitulatif d'avant génération est encore plus
   important ici : client, lignes, montants, type de facture, échéance.

## Étape 0, à chaque invocation : la configuration existe-t-elle ?

Cherche le fichier de configuration, dans cet ordre :

1. `config/entreprise.json` dans le dossier de ce skill ;
2. `entreprise-devis.json` ou `entreprise-facture.json` dans le dossier de
   travail courant.

- **Le fichier existe et contient un bloc `facture`** : lis-le (et
  `clients.json` à côté), va directement à « Faire une facture ».
- **Le fichier n'existe pas** : avant de dérouler un setup complet, cherche
  la configuration du skill devis (`generer-devis/config/entreprise.json`
  dans le dossier voisin de ce skill, ou `~/.claude/skills/generer-devis/config/`).
  Si elle existe, annonce la bonne nouvelle : « tu utilises déjà le skill
  devis, je reprends tout ce qu'il sait » ; copie `entreprise.json` et
  `clients.json` dans `config/` de ce skill, puis ne pose QUE les questions
  du bloc facture (ci-dessous). Sinon, setup complet.
- **Le fichier existe mais sans bloc `facture`** (config importée du devis) :
  pose uniquement les questions du bloc facture, une fois.

## Le setup de première utilisation

Si tout est à faire (pas de config devis à importer), reprendre les blocs
du setup du skill devis : entreprise (nom, forme, adresse, SIRET, mention EI
automatique pour les entrepreneurs individuels, capital et ville du RCS pour
les sociétés), TVA (franchise avec mention 293 B automatique, ou taux et
numéro de TVA intracommunautaire), métier (assurance décennale pour les
artisans du bâtiment : la loi l'exige sur chaque facture aussi), optionnels
(téléphone, email, site, logo), champs libres (texte simple ou étiquette +
valeur, l'utilisateur choisit où). Le pourquoi de chaque mention est dans
`references/mentions-obligatoires-facture.md` : consulter en cas de doute,
ne jamais improviser une réponse juridique.

Puis, dans tous les cas, le bloc FACTURE (les questions propres à ce skill,
posées une seule fois) :

1. **La numérotation des factures** : distincte de celle des devis, elle
   doit être CONTINUE et sans trou (c'est une exigence légale). Par défaut
   FA-ANNÉE-001. Si l'utilisateur a déjà émis des factures, demander son
   DERNIER numéro TEL QU'IL L'ÉCRIT et reprendre son format à l'identique,
   préfixe compris (« 2026-040 » donne `format_numero` « {annee}-{seq:03d} »
   sans préfixe, jamais « FA-2026-041 ») : changer le format en cours de
   série est une rupture de la séquence légale. Confirmer à l'utilisateur
   le prochain numéro qui sera émis. Le passage d'année est géré par le
   script : quand le format contient l'année, la séquence repart à 1 au
   1er janvier (série annuelle, admise par le BOFiP) ; le signaler à
   l'utilisateur à la première facture d'une nouvelle année, et pour ceux
   qui numérotent en continu d'une année sur l'autre, mettre
   `reset_annuel` à false dans le bloc facture.
2. **Le délai de paiement** : 30 jours par défaut (c'est aussi le défaut
   légal entre professionnels ; 60 jours maximum). L'échéance s'affiche en
   date pleine sur chaque facture.
3. **L'IBAN** : fortement conseillé sur une facture (c'est là que le client
   paie). Proposé, pas imposé.
4. **Modes de paiement acceptés** (virement, chèque, espèces, CB).
5. **Pénalités et escompte** (clients professionnels) : le skill applique
   les mentions légales par défaut (pénalités au taux BCE majoré de 10
   points, indemnité forfaitaire de 40 €, « Escompte pour paiement
   anticipé : néant ») ; demander seulement si l'utilisateur veut d'autres
   valeurs.
6. **Si l'utilisateur facture la TVA** : son numéro de TVA
   intracommunautaire est une mention obligatoire des factures (tolérance
   seulement sous 150 € HT) : s'il ne l'a pas donné au setup devis,
   insister gentiment ici (il est sur son avis de situation ou auprès de
   son SIE), et vérifier sa convention de prix (`prix_annonces` : HT, TTC
   ou demander à chaque fois).

Le setup manie du vocabulaire fiscal qui est du jargon pour un débutant.
Pour chaque terme, une formulation simple existe, l'utiliser d'office :
- franchise en base : « sur tes factures actuelles, est-ce qu'il y a une
  ligne TVA ? Si non, tu es sûrement en franchise » ;
- numéro de TVA intracommunautaire : « un code qui commence par FR suivi de
  11 chiffres, sur ton avis de situation ou tes anciennes factures » ;
- escompte : « une petite remise si le client paie avant l'échéance ; la
  plupart n'en font pas, on écrit alors la mention officielle "néant" » ;
- mention EI : ne pas poser de question, l'activer et dire pourquoi ;
- assurance décennale : « l'assurance obligatoire de ton métier du
  bâtiment, son nom est sur ton attestation ».

Annoncer une durée honnête : le setup complet fait une quinzaine de
questions, compter 5 à 10 minutes avec le SIRET, le numéro de TVA et
l'IBAN sous la main (2 minutes seulement si la config du skill devis est
importée). Écris la configuration (modèle :
`references/exemple-config.json`, y compris `prix_annonces`), montre un
récapitulatif en clair, propose une facture d'essai.

**Mise à jour** : « nouveau RIB », « je passe à 45 jours », « nouvelle
adresse » : modifier la ou les clés concernées, confirmer, sans redérouler
le setup.

## Faire une facture : deux portes d'entrée

### Porte 1 : depuis un devis (zéro ressaisie)

Si l'utilisateur mentionne un devis (« le devis DEV-2026-001 est accepté »,
« facture pour le chantier Martin »), cherche ses données avant de poser la
moindre question :

- le fichier de données à côté du devis : `Devis-NUMERO-Client.json` dans le
  dossier `Devis/` (créé par le skill devis à chaque génération) ;
- à défaut, le devis HTML lui-même (notre modèle est lisible : blocs
  émetteur/client, tableau des lignes, totaux) ;
- à défaut, demander à l'utilisateur de dire où est le devis, ou les infos.

Tout en découle : client, lignes, montants, TVA, référence du devis. Les
seules questions restantes sont celles que le devis ne contient pas :

- **Facture d'acompte** (le devis vient d'être signé) : le pourcentage est
  souvent déjà sur le devis (« acompte 30 % à la commande ») : le proposer,
  ne demander que s'il diffère. Type `acompte`, avec les lignes du devis en
  `base_lignes` : le script calcule le prorata exact, y compris par taux de
  TVA.
- **Facture de solde** (la prestation est finie) : type `solde`, toutes les
  lignes du devis, plus la déduction des acomptes déjà facturés. Cherche
  les factures d'acompte liées dans `Factures/` (leurs fichiers de données
  portent la référence du devis) et propose-les à la déduction ; demande la
  date de la prestation si inconnue (mention obligatoire).
- **Facture complète directe** (pas d'acompte) : type `complete`, lignes du
  devis, date de la prestation à demander si inconnue.

### Porte 2 : sans devis

2-3 questions maximum, comme le skill devis :

1. **Le client** : s'il est au carnet (`clients.json`), son nom suffit et le
   dire (« comme d'habitude »). Nouveau client : fiche complète en une fois
   (nom, adresse obligatoires ; SIRET si entreprise, téléphone, email
   proposés). Si le doute existe, demander si le client est une entreprise
   ou un particulier : les mentions de pénalités ne concernent que les
   professionnels, le script s'appuie sur le SIRET ou le champ
   `professionnel` du client.
2. **La prestation et les montants** : AVANT de demander, regarder le
   CATALOGUE (`catalogue.json` à côté du carnet clients, rempli
   automatiquement, partagé dans l'esprit avec le skill devis) : si la
   désignation ou la référence correspond à une fiche mémorisée, la
   PROPOSER (« le forfait shooting produit, 800 € HT comme d'habitude ? »)
   au lieu de redemander prix, détails ou unité. La mémoire propose,
   l'utilisateur décide : jamais un prix mémorisé appliqué sans
   confirmation, et sa parole met la fiche à jour. Sinon : lignes avec prix
   (et la référence produit si l'utilisateur en utilise, champ
   `reference`), et LA DATE de la vente ou de la prestation (obligatoire
   sur une facture ; « juillet 2026 » ou « du 4 au 8 août » suffisent). **Un prix annoncé est ambigu
   tant qu'on ne sait pas s'il est HT ou TTC.** La règle : en franchise de
   TVA, aucune ambiguïté, le prix est le prix. Avec TVA : ce que
   l'utilisateur a dit fait foi (« TTC », « tout compris », « HT ») ;
   sinon sa convention enregistrée (`prix_annonces` du bloc TVA, importée
   du skill devis le cas échéant) ; sinon poser LA question courte
   (« 850 €, c'est hors taxes ou TTC ? »). Jamais de déduction
   silencieuse. Pour un prix TTC, passer `prix_unitaire_ttc` au script :
   c'est lui qui convertit, et le récapitulatif montre toujours HT, TVA et
   TTC.
3. **Les particularités du jour** : bon de commande du client, échéance
   spéciale, mention libre.

### Dans les deux cas

- construis le fichier de facture (modèle : `references/exemple-facture.json`)
  dans un dossier temporaire ;
- montre le récapitulatif (règle 3) et attends l'accord ;
- appelle le script :

  ```bash
  python3 <dossier-du-skill>/scripts/generer_facture.py \
    --config <chemin-de-la-config> --facture <fichier-du-jour> \
    --sortie Factures --enregistrer
  ```

  `--enregistrer` fait avancer la numérotation (continue, sans trou) et
  mémorise le client. Ne l'omettre que pour un essai.
- si le script signale un manque, transforme son message en question, ne
  comble jamais le trou toi-même.

**Livraison** : ouvre le fichier pour l'utilisateur quand c'est possible
(`open` sur Mac, `start` sur Windows), donne le chemin complet (dossier
`Factures/`), rappelle le geste PDF (imprimer, « Enregistrer au format
PDF » ; le bandeau gris disparaît à l'impression). Ne montre jamais la
sortie brute du script : traduis en français courant (numéro, montants,
échéance, net à payer).

## Remises

Les réductions acquises sont une MENTION OBLIGATOIRE des factures : dès que
l'utilisateur accorde une remise, elle passe par les champs prévus, jamais
par une ligne négative bricolée ni un prix discrètement baissé :

- remise sur une ligne : `remise_pct` (pourcentage) ou `remise_montant`
  (montant HT) dans la ligne ; elle s'affiche sous la désignation ;
- remise globale : bloc `remise` de la facture (`{"libelle": "Remise
  fidélité", "pourcentage": 10}` ou `{"libelle": ..., "montant_ht": 50}`) ;
  elle s'affiche dans les totaux (« Total HT avant remise », puis la
  remise, puis le net).

La TVA est calculée par le script sur le montant APRÈS remise, comme
l'exige la règle fiscale. Une remise habituelle mémorisée (fiche client)
se PROPOSE, elle ne s'applique jamais sans confirmation.

## Préférences par client

La fiche d'un client au carnet peut porter ses particularités durables :
`delai_paiement_jours` (appliqué automatiquement par le script à
l'échéance : un client à 45 jours prime sur le défaut de la config),
une remise habituelle ou une adresse de chantier (que TOI tu proposes au
moment voulu, sans jamais les imposer). Quand l'utilisateur dit « pour lui
c'est toujours 45 jours », c'est dans sa fiche client que ça s'enregistre,
pas dans la config globale.

## La facture récurrente (« comme chaque mois »)

Quand l'utilisateur facture régulièrement la même chose au même client :
repartir du fichier de données de sa DERNIÈRE facture (le `.json` à côté
du HTML dans `Factures/`), garder les lignes, mettre à jour la date de
prestation, laisser la numérotation avancer. Proposer en une phrase
(« même facture que le mois dernier, 240 € pour la maintenance, sur
juillet ? ») et générer sur son accord. C'est le trio carnet + catalogue +
données de la dernière facture qui rend ça possible sans aucune ressaisie.

## L'export pour le comptable

Quand l'utilisateur veut son journal de factures (« exporte mes factures »,
« le récap pour mon comptable », « combien j'ai facturé ce trimestre ») :

```bash
python3 <dossier-du-skill>/scripts/exporter_journal.py \
  --factures Factures --sortie journal-factures.csv
```

Le script lit les données de toutes les factures générées et produit un
CSV prêt pour Excel en français (point-virgule, virgule décimale) : numéro,
type, dates, client, montants, les avoirs en négatif. Donner le total net
en clair avec le fichier.

## Plusieurs factures d'un coup (mode rafale)

« J'ai 4 factures à faire » : collecter TOUTES les variables en une passe
(le vrac dans un seul message est bienvenu), UN récapitulatif groupé, UNE
validation, puis génération en série avec `--enregistrer` : la numérotation
avance toute seule, les nouveaux clients entrent au carnet, et l'utilisateur
récupère tous les fichiers d'un coup.

## Se tromper, corriger : les avoirs

Une facture PAS ENCORE envoyée au client peut être régénérée avec le même
numéro (champ `numero`, sans `--enregistrer`). Une facture DÉJÀ envoyée ne
se modifie JAMAIS : elle se corrige par un AVOIR, que ce skill sait faire
(type `avoir`) :

- le bloc `facture_initiale` (numéro ET date de la facture corrigée) est
  obligatoire : un avoir qui ne référence pas sa facture est non conforme ;
- les `lignes` décrivent ce qui est crédité (tout ou partie de la facture,
  ou juste la différence en cas d'erreur de prix) ;
- les avoirs ont leur propre série de numéros (AV-ANNÉE-001 par défaut,
  compteur dédié dans la config), la série des factures reste continue ;
- l'option `net_de_taxe: true` produit un avoir sans TVA (quand on renonce
  à récupérer la TVA), avec sa mention ;
- le document dit « À valoir sur vos prochains règlements » : pas
  d'échéance, pas de pénalités.

Le réflexe en cas d'erreur signalée : demander si la facture est partie.
Pas partie : régénération même numéro. Partie : avoir (total ou de la
différence) puis, s'il faut refacturer, une nouvelle facture au numéro
suivant. Ne jamais réutiliser un numéro émis : la séquence est continue ou
elle n'est rien.

## La facturation électronique (question fréquente)

Si l'utilisateur demande « et la facture électronique ? », « mon comptable
me parle de Chorus / PDP » : lire la section dédiée de
`references/mentions-obligatoires-facture.md` et répondre honnêtement
(calendrier de la réforme, qui est concerné, jusqu'à quand le PDF reste
suffisant selon le client). Ce skill produit des factures classiques ; il ne
télétransmet rien.

## Ce que ce skill ne fait pas

Pas de devis (c'est le skill generer-devis, son compagnon naturel), pas de
relances d'impayés, pas de comptabilité au-delà de l'export du journal,
pas de télétransmission (Chorus Pro, plateformes de dématérialisation), pas
de conseil juridique ou fiscal personnalisé : pour une question de droit,
citer `references/mentions-obligatoires-facture.md` et ses sources
officielles, et en cas de doute persistant, le dire plutôt que trancher.
