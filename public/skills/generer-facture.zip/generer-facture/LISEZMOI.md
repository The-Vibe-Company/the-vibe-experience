# Générer une facture : le mode d'emploi

Ce skill fait tes factures à ta place. Le cas magique : ton devis accepté
devient une facture en une phrase (« le devis DEV-2026-001 est signé, fais la
facture d'acompte »), sans rien ressaisir. Et si tu ne fais pas de devis, il
fait aussi tes factures de zéro : tu réponds à 2-3 questions et tu obtiens
une facture conforme au droit français, numérotée proprement, avec ton
échéance de paiement et tes mentions.

Il sait faire les quatre documents de la vraie vie : la facture classique,
la facture d'acompte quand tu encaisses une avance, la facture de solde qui
déduit toute seule les acomptes déjà facturés, et l'avoir quand une facture
déjà envoyée doit être corrigée (avec sa propre numérotation et la
référence à la facture d'origine, comme la loi le demande). Il gère aussi
tes remises (par ligne ou globales, la TVA se recalcule toute seule sur le
net), retient tes prestations habituelles et tes clients (« la même chose
que d'habitude » suffit), écrit le montant en toutes lettres sur la
facture, et sort le journal de tes factures en un fichier Excel pour ton
comptable.

Il est fait pour les indépendants et les petites entreprises françaises. Si
tu utilises déjà son compagnon (le skill de devis), il récupère tout ce que
tu lui as déjà dit : tu ne refais pas le setup.

## Ce qu'il te faut (honnêtement)

- Un abonnement Claude payant : la version gratuite ne suffit pas,
  l'abonnement Pro (environ 20 € par mois) suffit. Si un jour tu factures
  en trop grand volume pour le Pro, le plan au-dessus existe, à toi de voir
  selon le temps gagné.
- L'application Claude qui lit les skills et travaille dans un dossier :
  Claude Code, ou l'application de bureau Claude (Mac ou Windows).
- Rien d'autre. Aucun logiciel, aucun abonnement en plus. La facture sort en
  fichier HTML que tu transformes en PDF en l'imprimant (« Enregistrer au
  format PDF »).

Un point d'honnêteté sur la facturation électronique : une réforme française
impose progressivement (2026-2027) la facture électronique entre entreprises
via des plateformes agréées. Ce skill produit des factures classiques (PDF),
qui restent valables pour tes clients particuliers et, selon le calendrier,
pour ta taille d'entreprise. Il t'expliquera où tu en es si tu lui poses la
question, sans te vendre du rêve.

## Les trois gestes

**Geste 1 : installe le skill.** Le plus simple : demande à Claude de le
faire. Ouvre Claude et écris : « installe le skill generer-facture qui est
dans mon dossier Téléchargements » (ou l'endroit où tu l'as mis). Si tu
préfères l'application de bureau : Réglages, puis Capacités, puis Skills,
et importe le fichier téléchargé.

**Geste 2 : la première fois, laisse-le faire connaissance.** Écris
« fais-moi une facture », ou n'importe quelle phrase à toi : il n'y a pas
de formule magique à connaître. Deux cas :
- Tu utilises déjà le skill de devis : il retrouve tout (ton entreprise, ta
  TVA, tes clients) et ne te pose que les questions propres aux factures :
  ta numérotation de factures, ton délai de paiement, ton IBAN. Deux
  minutes.
- Tu pars de zéro : il te pose une quinzaine de questions, une seule fois ;
  compte 5 à 10 minutes avec ton SIRET, ton numéro de TVA et ton IBAN sous
  la main. Si tu as déjà émis des factures, retrouve ton dernier numéro
  tel que tu l'écris : ta numérotation doit se suivre sans trou, c'est la
  loi, et il la reprendra à l'identique.

**Geste 3 : facture.** « Le devis DEV-2026-012 est accepté, facture
d'acompte de 30 % » ou « facture pour Mme Martin : retouches rideaux, 240
euros, prestation du 12 août ». Il te montre un récapitulatif, tu dis oui,
le fichier est prêt. Plusieurs factures à faire ? Donne tout d'un coup, il
les sort en série.

## Et si quelque chose change

« Nouveau RIB », « je passe les paiements à 45 jours », « j'ai déménagé » :
dis-le, il met à jour juste ça. Attention, particularité des factures : une
facture déjà envoyée ne se corrige pas, elle s'annule par un avoir (le
skill t'expliquera la marche à suivre le cas échéant).

## Ce qu'il ne fait pas

Les devis (c'est son compagnon generer-devis), les relances d'impayés, la
comptabilité au-delà de l'export du journal, et la télétransmission
électronique (Chorus Pro, plateformes agréées). Il ne donne pas de conseil juridique :
il applique les règles officielles, sourcées dans le dossier `references`.

---

Un skill The Vibe Company (thevibecompany.co). Libre d'utilisation, sans
support garanti.
