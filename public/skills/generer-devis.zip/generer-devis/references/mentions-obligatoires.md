# Le devis en droit français : ce qui est obligatoire, ce qui est usage

Référence pour répondre aux questions de l'utilisateur et remplir la
configuration sans improviser. Chaque règle est marquée LOI (obligation
textuelle) ou USAGE (pratique recommandée). État du droit : juillet 2026,
sources officielles en bas de page. Ne jamais donner de conseil juridique
personnalisé au-delà de ces règles : renvoyer aux sources.

## Ce qu'est un devis

LOI (droit des contrats). Le devis est une offre de contrat : il engage le
professionnel sur le contenu et le prix pendant sa durée de validité
(code civil, art. 1116 : l'offre ne peut pas être retirée avant l'expiration
du délai fixé). Signé par le client, il devient un contrat qui engage les
deux parties. La formule « bon pour accord » est un usage, pas une
obligation : c'est la signature qui compte.

## Quand le devis est obligatoire (clients particuliers)

LOI. Fondement : art. L112-1 du code de la consommation + arrêtés
sectoriels. Sanction : amende administrative jusqu'à 3 000 € (personne
physique) / 15 000 € (société), art. L131-5.

- Travaux et dépannage du bâtiment et de l'équipement de la maison
  (plomberie, électricité, maçonnerie, toiture, serrurerie, isolation…) :
  devis obligatoire avant exécution, SANS seuil de montant (arrêté du
  24 janvier 2017).
- Déménagement (arrêté du 27 avril 2010).
- Services à la personne : devis GRATUIT obligatoire dès 100 € TTC par mois
  (arrêté du 17 mars 2015).
- Produits et prestations d'autonomie : dès 500 € TTC.
- Chirurgie esthétique : dès 300 € ou anesthésie générale.
- Location de véhicules sans chauffeur (< 3,5 t).
- Optique, audioprothèse, funéraire : devis obligatoires sur MODÈLES
  RÉGLEMENTAIRES imposés. Ce skill ne les couvre pas : le dire à
  l'utilisateur de ces secteurs.

Hors secteurs listés : devis non imposé, mais recommandé (il reste la
meilleure preuve de l'accord).

## Mentions générales du devis

La liste la plus complète vient de l'arrêté du 24 janvier 2017 (art. 4),
obligatoire pour le bâtiment ; ailleurs c'est l'usage conforme :

- la mention « Devis » et la date de rédaction ;
- nom, raison sociale, adresse, coordonnées du professionnel ;
- nom et adresse du client ;
- lieu d'exécution de la prestation (travaux) ;
- décompte détaillé de chaque prestation et produit : quantité et prix
  unitaire ; prix de la main-d'œuvre et frais de déplacement le cas
  échéant ;
- somme globale HT et TTC avec taux de TVA ;
- durée de validité de l'offre ;
- caractère gratuit ou payant du devis (le devis payant est légal si le
  client en est informé AVANT) ;
- date de début et durée estimée des travaux le cas échéant.

## Mentions liées au statut (tous clients, y compris professionnels)

- LOI. Sociétés : forme juridique + capital social (code de commerce,
  art. R123-238), numéro SIREN + « RCS » et ville du greffe
  (art. R123-237) sur les documents commerciaux.
- LOI. Entrepreneur individuel (dont micro-entrepreneur) : le nom précédé
  ou suivi immédiatement de « EI » ou « entrepreneur individuel » sur tout
  document professionnel, devis compris (art. R526-27 code de commerce,
  décret 2022-725 ; amende 750 €). Attention : le « répertoire des
  métiers (RM) » n'existe plus, les artisans sont au Registre national des
  entreprises (RNE) depuis 2023 ; ne pas mettre de mention RM.
- LOI. Franchise en base de TVA (micro-entrepreneurs sous les seuils) :
  mention exacte « TVA non applicable, art. 293 B du CGI », prix sans TVA.
  Seuils 2026 confirmés : 85 000 € ventes / 37 500 € services (majorés
  93 500 / 41 250). Le projet de seuil unique à 25 000 € a été ABANDONNÉ.

## Artisans : l'assurance sur chaque devis

LOI. Art. L132-1 du code de l'artisanat (reprend l'ancien art. 22-2 de la
loi du 5 juillet 1996, abrogé en 2023) : les entreprises artisanales et
micro-entrepreneurs dont le métier exige une assurance professionnelle
(décennale du bâtiment notamment) indiquent sur CHAQUE devis et facture :
l'assurance souscrite, les coordonnées de l'assureur, la couverture
géographique du contrat. Le numéro de contrat est un usage utile, pas une
obligation.

## TVA réduite bâtiment (10 % et 5,5 %)

LOI, règle récente. Depuis le 1er mars 2025 (loi de finances 2025,
art. 41), plus d'attestation Cerfa : le client certifie DIRECTEMENT SUR LE
DEVIS signé que le local d'habitation est achevé depuis plus de deux ans et
que les conditions du taux réduit sont remplies. Le script ajoute cette
mention automatiquement dès qu'une ligne porte un taux de 10 % ou 5,5 %.
Chacun conserve sa copie (client : 5 ans).

## Acompte, médiateur, et ce qui relève de la facture

- Acompte : LOI sur la qualification. Par défaut, une somme versée d'avance
  par un particulier est des « arrhes » (chacun peut se dédire,
  art. L214-1 code conso). Pour un engagement ferme, écrire le mot
  « acompte ». C'est ce que fait le modèle.
- Médiateur de la consommation : LOI (art. L616-1 code conso), le
  professionnel qui sert des particuliers doit communiquer son médiateur
  (site, CGV ou bons de commande). Le devis est un bon support : champ
  optionnel proposé au setup.
- Pénalités de retard, escompte, indemnité de 40 € : obligatoires sur les
  FACTURES entre professionnels (art. L441-9 code de commerce), pas sur les
  devis. Les afficher sur un devis est un usage utile, jamais une erreur.
- Numéro de devis : aucune obligation légale (contrairement à la facture),
  mais indispensable en gestion : le skill numérote toujours.

## Durée de validité

LOI sur la mention (bâtiment), pas sur la durée : aucune durée légale.
30 jours est l'usage courant (60 ou 90 selon les métiers). Pendant ce
délai, l'offre engage le professionnel (art. 1116 code civil).

## Sources officielles

- entreprendre.service-public.gouv.fr/vosdroits/F31144 (devis
  obligatoire : secteurs, mentions, sanctions)
- legifrance.gouv.fr/jorf/id/JORFTEXT000033935513 (arrêté du 24 janvier
  2017, art. 4 : contenu du devis bâtiment)
- entreprendre.service-public.gouv.fr/vosdroits/F21746 (franchise de TVA,
  seuils 2026, mention 293 B)
- entreprendre.service-public.gouv.fr/actualites/A15744 (mention « EI »)
- legifrance.gouv.fr/codes/article_lc/LEGIARTI000047362294 (L132-1 code de
  l'artisanat : assurance sur devis et factures)
- legifrance.gouv.fr : R123-237 et R123-238 code de commerce (SIREN, RCS,
  forme, capital), L214-1 et L616-1 code de la consommation, art. 1116
  code civil
- service-public.fr/particuliers/actualites/A18088 et BOFiP
  BOI-TVA-LIQ-30-20-90-40 (TVA réduite : certification sur devis depuis
  mars 2025)
