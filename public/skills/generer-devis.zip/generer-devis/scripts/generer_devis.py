#!/usr/bin/env python3
"""Générateur de devis : transforme la configuration de l'entreprise + les données
du devis du jour en un fichier HTML A4 prêt à imprimer en PDF.

Usage :
  python3 generer_devis.py --config <config/entreprise.json> --devis <devis.json>
                           [--sortie <dossier>] [--enregistrer]

- --config    : le fichier de configuration créé au setup de première utilisation.
- --devis     : les données du devis du jour (client, lignes, options).
- --sortie    : dossier où écrire le devis (défaut : ./Devis).
- --enregistrer : incrémente le compteur de numérotation dans la config et
                  mémorise le client dans le carnet (config/clients.json).

Le script est volontairement en Python standard, sans aucune dépendance :
il doit tourner tel quel sur n'importe quelle machine.

Tous les calculs (totaux, TVA) sont faits ici et seulement ici : l'agent ne
calcule jamais un total à la main.
"""

import argparse
import base64
import datetime
import html
import json
import mimetypes
import os
import re
import sys
import unicodedata

MOIS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
           "août", "septembre", "octobre", "novembre", "décembre"]

MENTION_FRANCHISE = "TVA non applicable, art. 293 B du CGI"


def erreur(msg):
    print(f"ERREUR : {msg}", file=sys.stderr)
    sys.exit(1)


def charger_json(chemin, nom):
    if not os.path.exists(chemin):
        erreur(f"fichier {nom} introuvable : {chemin}")
    try:
        with open(chemin, encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        erreur(f"le fichier {nom} n'est pas un JSON valide ({chemin}) : {e}")


def date_fr(d):
    return f"{d.day} {MOIS_FR[d.month - 1]} {d.year}"


def parser_date(texte):
    """Accepte AAAA-MM-JJ ou JJ/MM/AAAA."""
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.datetime.strptime(texte, fmt).date()
        except ValueError:
            continue
    erreur(f"date illisible : « {texte} » (formats acceptés : AAAA-MM-JJ ou JJ/MM/AAAA)")


def montant_fr(valeur):
    """1234.5 -> « 1 234,50 € » (espace insécable fine pour les milliers)."""
    entier, decimales = f"{valeur:,.2f}".split(".")
    entier = entier.replace(",", " ")
    return f"{entier},{decimales} €"


def nombre_fr(valeur):
    """Quantité : sans décimales inutiles (2.0 -> 2 ; 2.5 -> 2,5)."""
    if float(valeur) == int(float(valeur)):
        return str(int(float(valeur)))
    return f"{float(valeur):g}".replace(".", ",")


def slug(texte):
    texte = unicodedata.normalize("NFKD", texte).encode("ascii", "ignore").decode()
    texte = re.sub(r"[^A-Za-z0-9]+", "-", texte).strip("-")
    return texte or "client"


def e(texte):
    return html.escape(str(texte), quote=True)


def valider(config, devis):
    """Vérifie que rien d'obligatoire ne manque. Les messages sont écrits pour
    être montrés tels quels à l'utilisateur : clairs, en français, actionnables."""
    manques = []

    ent = config.get("entreprise", {})
    for champ, libelle in [("nom", "le nom de l'entreprise"),
                           ("adresse_lignes", "l'adresse de l'entreprise"),
                           ("siret", "le numéro SIREN ou SIRET")]:
        if not ent.get(champ):
            manques.append(f"{libelle} (configuration, bloc « entreprise »)")

    client = devis.get("client", {})
    if not client.get("nom"):
        manques.append("le nom du client (devis, bloc « client »)")
    if not client.get("adresse_lignes"):
        manques.append("l'adresse du client (devis, bloc « client »)")

    lignes = devis.get("lignes", [])
    if not lignes:
        manques.append("au moins une ligne de prestation (devis, « lignes »)")
    for i, l in enumerate(lignes, 1):
        if not l.get("description"):
            manques.append(f"la description de la ligne {i}")
        if l.get("prix_unitaire_ht") is None and l.get("prix_unitaire_ttc") is None:
            manques.append(f"le prix unitaire de la ligne {i} (HT ou TTC)")

    tva = config.get("tva", {})
    if not tva.get("franchise") and tva.get("taux_defaut") is None:
        manques.append("le taux de TVA par défaut (configuration, bloc « tva ») "
                       "ou le régime de franchise en base")

    if config.get("assurance", {}).get("obligatoire"):
        ass = config["assurance"]
        if not ass.get("nom_assureur"):
            manques.append("le nom de l'assureur (configuration, bloc « assurance » : "
                           "obligatoire pour les activités du bâtiment)")

    if manques:
        erreur("le devis ne peut pas être généré, il manque :\n  - " + "\n  - ".join(manques))


def numero_devis(config, devis, date_emission):
    if devis.get("numero"):
        return str(devis["numero"]), False
    d = config.get("devis", {})
    prefixe = d.get("prefixe_numero", "DEV")
    seq = int(d.get("prochain_numero", 1))
    fmt = d.get("format_numero", "{prefixe}-{annee}-{seq:03d}")
    # Passage d'année : format avec année = série annuelle, la séquence repart
    # à 1 au 1er janvier (désactivable avec "reset_annuel": false).
    if "{annee}" in fmt and d.get("reset_annuel", True):
        annee_serie = d.get("annee_serie")
        if annee_serie is not None and int(annee_serie) != date_emission.year:
            seq = 1
    return fmt.format(prefixe=prefixe, annee=date_emission.year, seq=seq), True


def bloc_logo(config, base_config):
    chemin = config.get("entreprise", {}).get("logo")
    if not chemin:
        return f'<div style="font-size:16pt;font-weight:700;">{e(config["entreprise"]["nom"])}</div>'
    if not os.path.isabs(chemin):
        chemin = os.path.join(os.path.dirname(base_config), chemin)
    if not os.path.exists(chemin):
        print(f"AVERTISSEMENT : logo introuvable ({chemin}), le nom de l'entreprise est "
              "affiché à la place.", file=sys.stderr)
        return f'<div style="font-size:16pt;font-weight:700;">{e(config["entreprise"]["nom"])}</div>'
    mime = mimetypes.guess_type(chemin)[0] or "image/png"
    with open(chemin, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return f'<img src="data:{mime};base64,{b64}" alt="{e(config["entreprise"]["nom"])}">'


def bloc_adresse(nom, lignes, extras):
    out = [f'<div class="nom">{e(nom)}</div>']
    for ligne in lignes:
        out.append(f"<div>{e(ligne)}</div>")
    for extra in extras:
        out.append(f"<div>{e(extra)}</div>")
    return "\n".join(out)


def champ_libre_texte(cl):
    """Un champ libre est soit une simple chaîne (affichée telle quelle), soit
    un couple {label, valeur}. Les deux formes sont acceptées partout : un
    utilisateur qui veut juste une ligne (« Membre des Artisans... ») ne doit
    pas être forcé dans un format étiquette/valeur."""
    if isinstance(cl, str):
        return cl
    return f"{cl['label']} : {cl['valeur']}"


def construire_emetteur(config):
    ent = config["entreprise"]
    nom = ent["nom"]
    if ent.get("forme_juridique"):
        nom = f"{nom} ({ent['forme_juridique']})"
    if ent.get("mention_ei"):
        nom = f"{nom} EI"
    extras = []
    if ent.get("siret"):
        extras.append(f"SIRET {ent['siret']}" if len(re.sub(r"\D", "", str(ent["siret"]))) == 14
                      else f"SIREN {ent['siret']}")
    for champ, gabarit in [("telephone", "Tél. {}"), ("email", "{}"), ("site_web", "{}")]:
        if ent.get(champ):
            extras.append(gabarit.format(ent[champ]))
    for cl in config.get("champs_libres", []):
        extras.append(champ_libre_texte(cl))
    return bloc_adresse(nom, ent.get("adresse_lignes", []), extras)


def construire_client(devis):
    c = devis["client"]
    extras = []
    if c.get("siret"):
        extras.append(f"SIRET {c['siret']}")
    for champ in ("email", "telephone"):
        if c.get(champ):
            extras.append(c[champ])
    for cl in c.get("champs_libres", []):
        extras.append(champ_libre_texte(cl))
    return bloc_adresse(c["nom"], c.get("adresse_lignes", []), extras)


def construire_champs_devis(devis):
    """Champs du jour hors tableau : lieu d'exécution, date de début, durée, champs libres."""
    lignes = []
    if devis.get("lieu_execution"):
        lignes.append(("Lieu d'exécution", devis["lieu_execution"]))
    if devis.get("date_debut"):
        lignes.append(("Début de la prestation", devis["date_debut"]))
    if devis.get("duree_estimee"):
        lignes.append(("Durée estimée", devis["duree_estimee"]))
    if devis.get("echeance"):
        lignes.append(("À réaliser pour le", devis["echeance"]))
    for cl in devis.get("champs_libres", []):
        if isinstance(cl, str):
            lignes.append((None, cl))
        else:
            lignes.append((cl["label"], cl["valeur"]))
    if not lignes:
        return ""
    interieur = "\n".join(
        f"<div>{e(v)}</div>" if l is None else f"<div><strong>{e(l)} :</strong> {e(v)}</div>"
        for l, v in lignes)
    return f'<section class="champs-devis">\n{interieur}\n</section>'


def calculer(config, devis):
    """Totaux HT, TVA par taux, TTC, avec remises. Les remises par ligne
    (remise_pct ou remise_montant) s'appliquent au montant de la ligne ; la
    remise globale du devis ({libelle, pourcentage} ou {libelle, montant_ht})
    se répartit au prorata des taux, et la TVA se calcule TOUJOURS sur le net
    après remise. Seule source de vérité des calculs."""
    franchise = bool(config.get("tva", {}).get("franchise"))
    taux_defaut = config.get("tva", {}).get("taux_defaut", 20)
    brut_par_taux = {}
    lignes_calc = []
    for l in devis["lignes"]:
        qte = float(l.get("quantite", 1))
        taux = 0 if franchise else float(l.get("taux_tva", taux_defaut))
        if l.get("prix_unitaire_ht") is not None:
            pu = float(l["prix_unitaire_ht"])
        else:
            # Prix annoncé en TTC : la conversion vers le HT se fait ICI, jamais
            # de tête par l'agent (en franchise, TTC = HT, le taux vaut 0).
            pu = round(float(l["prix_unitaire_ttc"]) / (1 + taux / 100), 2)
        brut = round(qte * pu, 2)
        remise = 0.0
        if l.get("remise_pct"):
            remise = round(brut * float(l["remise_pct"]) / 100, 2)
        elif l.get("remise_montant"):
            remise = round(float(l["remise_montant"]), 2)
        montant = round(brut - remise, 2)
        brut_par_taux[taux] = round(brut_par_taux.get(taux, 0.0) + montant, 2)
        lignes_calc.append({**l, "quantite": qte, "prix_unitaire_ht": pu,
                            "montant_brut_ht": brut, "remise_ht": remise,
                            "montant_ht": montant, "taux_tva": taux})
    total_avant_remise = round(sum(brut_par_taux.values()), 2)
    remise_g = 0.0
    libelle_remise = ""
    rg = devis.get("remise")
    if rg and total_avant_remise > 0:
        libelle_remise = rg.get("libelle", "Remise")
        if rg.get("pourcentage") is not None:
            remise_g = round(total_avant_remise * float(rg["pourcentage"]) / 100, 2)
            libelle_remise += f" ({nombre_fr(rg['pourcentage'])} %)"
        else:
            remise_g = round(float(rg["montant_ht"]), 2)
        restant = remise_g
        taux_tries = sorted(brut_par_taux)
        for i, taux in enumerate(taux_tries):
            part = restant if i == len(taux_tries) - 1 else \
                round(remise_g * brut_par_taux[taux] / total_avant_remise, 2)
            brut_par_taux[taux] = round(brut_par_taux[taux] - part, 2)
            restant = round(restant - part, 2)
    total_ht = round(sum(brut_par_taux.values()), 2)
    tva_par_taux = {}
    if not franchise:
        for taux, base in brut_par_taux.items():
            if taux:
                tva_par_taux[taux] = round(base * taux / 100, 2)
    total_tva = round(sum(tva_par_taux.values()), 2)
    total_ttc = round(total_ht + total_tva, 2)
    return {"franchise": franchise, "lignes": lignes_calc, "total_ht": total_ht,
            "total_ht_avant_remise": total_avant_remise, "remise_globale_ht": remise_g,
            "libelle_remise": libelle_remise,
            "tva_par_taux": tva_par_taux, "total_tva": total_tva, "total_ttc": total_ttc}


def construire_tableau(calc):
    franchise = calc["franchise"]
    plusieurs_taux = len(calc["tva_par_taux"]) > 1
    entetes = ["<th>Désignation</th>", '<th class="num">Qté</th>',
               '<th class="num">PU HT</th>']
    if plusieurs_taux:
        entetes.append('<th class="num">TVA</th>')
    entetes.append('<th class="num">Total HT</th>')
    rangs = []
    for l in calc["lignes"]:
        titre = l["description"]
        if l.get("reference"):
            titre = f"{titre} (réf. {l['reference']})"
        desc = f"<strong>{e(titre)}</strong>"
        if l.get("details"):
            desc += f'<div class="desc-details">{e(l["details"])}</div>'
        if l.get("remise_ht"):
            detail_remise = f"Remise : -{montant_fr(l['remise_ht'])}"
            if l.get("remise_pct"):
                detail_remise += f" ({nombre_fr(l['remise_pct'])} %)"
            desc += f'<div class="desc-details">{e(detail_remise)}</div>'
        qte = nombre_fr(l["quantite"])
        if l.get("unite"):
            unite = l["unite"]
            # Accord du pluriel des unités en toutes lettres (« 3 paires », « 2 jours »).
            # Les symboles courts (h, m2, kg...) et les mots déjà au pluriel restent tels quels.
            if l["quantite"] > 1 and len(unite) > 2 and unite[-1].isalpha() \
               and unite[-1] not in "sxz":
                unite += "s"
            qte += f" {e(unite)}"
        cellules = [f"<td>{desc}</td>", f'<td class="num">{qte}</td>',
                    f'<td class="num">{montant_fr(l["prix_unitaire_ht"])}</td>']
        if plusieurs_taux:
            cellules.append(f'<td class="num">{nombre_fr(l["taux_tva"])} %</td>')
        cellules.append(f'<td class="num">{montant_fr(l["montant_ht"])}</td>')
        rangs.append("<tr>" + "".join(cellules) + "</tr>")
    return "".join(entetes), "\n".join(rangs)


def construire_totaux(calc):
    rangs = []
    if calc.get("remise_globale_ht"):
        rangs.append(f"<tr><td>Total HT avant remise</td>"
                     f"<td>{montant_fr(calc['total_ht_avant_remise'])}</td></tr>")
        rangs.append(f"<tr><td>{e(calc['libelle_remise'])}</td>"
                     f"<td>-{montant_fr(calc['remise_globale_ht'])}</td></tr>")
    rangs.append(f"<tr><td>Total HT</td><td>{montant_fr(calc['total_ht'])}</td></tr>")
    if calc["franchise"]:
        rangs.append(f'<tr class="total-final"><td>Total à payer</td>'
                     f"<td>{montant_fr(calc['total_ht'])}</td></tr>")
    else:
        for taux in sorted(calc["tva_par_taux"]):
            rangs.append(f"<tr><td>TVA {nombre_fr(taux)} %</td>"
                         f"<td>{montant_fr(calc['tva_par_taux'][taux])}</td></tr>")
        rangs.append(f'<tr class="total-final"><td>Total TTC</td>'
                     f"<td>{montant_fr(calc['total_ttc'])}</td></tr>")
    return "\n".join(rangs)


def construire_mentions(config, devis, calc, date_validite):
    d = config.get("devis", {})
    mentions = []
    mentions.append(f"Devis {'gratuit' if d.get('devis_gratuit', True) else 'payant'}, "
                    f"valable jusqu'au {date_fr(date_validite)}.")
    if calc["franchise"]:
        mentions.append(MENTION_FRANCHISE + ".")
    if devis.get("acompte") or d.get("acompte"):
        mentions.append(f"Acompte : {devis.get('acompte') or d.get('acompte')}.")
    if d.get("conditions_paiement"):
        mentions.append(f"Règlement : {d['conditions_paiement']}.")
    if d.get("iban"):
        mentions.append(f"IBAN : {d['iban']}.")
    ass = config.get("assurance", {})
    if ass.get("obligatoire") and ass.get("nom_assureur"):
        texte = (f"Assurance {ass.get('type', 'de responsabilité décennale')} souscrite auprès de "
                 f"{ass['nom_assureur']}")
        if ass.get("coordonnees_assureur"):
            texte += f" ({ass['coordonnees_assureur']})"
        if ass.get("couverture_geographique"):
            texte += f", couverture géographique : {ass['couverture_geographique']}"
        mentions.append(texte + ".")
    taux_reduits = [t for t in calc["tva_par_taux"] if t in (5.5, 10.0)]
    if taux_reduits:
        # Depuis le 1er mars 2025 (LF 2025, art. 41), l'attestation Cerfa est remplacée
        # par une certification portée directement sur le devis signé.
        mentions.append("En signant ce devis, le client certifie que les travaux portent sur "
                        "un local d'habitation achevé depuis plus de deux ans et que les "
                        "conditions d'application du taux réduit de TVA sont remplies.")
    med = config.get("mediateur", {})
    if med.get("nom"):
        texte = f"Médiateur de la consommation : {med['nom']}"
        if med.get("site"):
            texte += f" (site : {med['site']})"
        mentions.append(texte + ".")
    for m in d.get("mentions_libres", []):
        mentions.append(m)
    for m in devis.get("mentions_libres", []):
        mentions.append(m)
    mentions.append("Le devis signé avec la mention « bon pour accord » engage les deux parties.")
    return "\n".join(f"<p>{e(m)}</p>" for m in mentions)


def construire_pied(config):
    ent = config["entreprise"]
    morceaux = [ent["nom"]]
    if ent.get("forme_juridique"):
        morceaux[-1] += f" — {ent['forme_juridique']}"
    if ent.get("mention_ei"):
        morceaux[-1] += " EI"
    if ent.get("capital_social"):
        morceaux.append(f"Capital social : {ent['capital_social']}")
    if ent.get("siret"):
        morceaux.append(f"SIRET {ent['siret']}")
    if ent.get("rcs_ou_rm"):
        morceaux.append(ent["rcs_ou_rm"])
    tva = config.get("tva", {})
    if tva.get("numero_tva_intra"):
        morceaux.append(f"TVA intracommunautaire : {tva['numero_tva_intra']}")
    return e(" · ".join(morceaux))


def main():
    p = argparse.ArgumentParser(description="Génère un devis HTML prêt à imprimer en PDF.")
    p.add_argument("--config", required=True)
    p.add_argument("--devis", required=True)
    p.add_argument("--sortie", default="Devis")
    p.add_argument("--enregistrer", action="store_true",
                   help="incrémente le compteur et mémorise le client dans le carnet")
    args = p.parse_args()

    config = charger_json(args.config, "de configuration")
    devis = charger_json(args.devis, "du devis")
    valider(config, devis)

    date_emission = parser_date(devis["date"]) if devis.get("date") else datetime.date.today()
    validite_jours = int(config.get("devis", {}).get("validite_jours", 30))
    date_validite = date_emission + datetime.timedelta(days=validite_jours)
    numero, numero_auto = numero_devis(config, devis, date_emission)

    calc = calculer(config, devis)
    entetes, rangs = construire_tableau(calc)

    modele_chemin = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "..", "assets", "modele-devis.html")
    with open(modele_chemin, encoding="utf-8") as f:
        page = f.read()

    remplacements = {
        "{{TITRE_DOCUMENT}}": e(f"Devis {numero} — {devis['client']['nom']}"),
        "{{BLOC_LOGO}}": bloc_logo(config, args.config),
        "{{NUMERO}}": e(numero),
        "{{DATE_EMISSION}}": e(date_fr(date_emission)),
        "{{DATE_VALIDITE}}": e(date_fr(date_validite)),
        "{{BLOC_EMETTEUR}}": construire_emetteur(config),
        "{{BLOC_CLIENT}}": construire_client(devis),
        "{{BLOC_CHAMPS_DEVIS}}": construire_champs_devis(devis),
        "{{ENTETES_COLONNES}}": entetes,
        "{{LIGNES_TABLEAU}}": rangs,
        "{{LIGNES_TOTAUX}}": construire_totaux(calc),
        "{{BLOC_MENTIONS}}": construire_mentions(config, devis, calc, date_validite),
        "{{NOM_EMETTEUR}}": e(config["entreprise"]["nom"]),
        "{{PIED_DE_PAGE}}": construire_pied(config),
    }
    for cle, valeur in remplacements.items():
        page = page.replace(cle, valeur)

    os.makedirs(args.sortie, exist_ok=True)
    nom_fichier = f"Devis-{slug(numero)}-{slug(devis['client']['nom'])}.html"
    chemin_sortie = os.path.join(args.sortie, nom_fichier)
    with open(chemin_sortie, "w", encoding="utf-8") as f:
        f.write(page)

    # Fichier de données à côté du devis (même nom, extension .json) : c'est lui
    # qui permet à un autre outil (ex. le générateur de factures) de reprendre le
    # devis sans aucune ressaisie. Il contient les données du jour ET les totaux
    # calculés, figés au moment de la génération.
    donnees = {
        "type": "devis",
        "genere_par": "generer-devis",
        "numero": numero,
        "date_emission": date_emission.isoformat(),
        "valable_jusquau": date_validite.isoformat(),
        "client": devis["client"],
        "lignes": calc["lignes"],
        "totaux": {
            "total_ht": calc["total_ht"],
            "tva_par_taux": {str(k): v for k, v in calc["tva_par_taux"].items()},
            "total_tva": calc["total_tva"],
            "total_ttc": calc["total_ttc"],
            "franchise_tva": calc["franchise"],
        },
        "acompte": devis.get("acompte") or config.get("devis", {}).get("acompte", ""),
        "lieu_execution": devis.get("lieu_execution", ""),
        "date_debut": devis.get("date_debut", ""),
        "duree_estimee": devis.get("duree_estimee", ""),
        "echeance": devis.get("echeance", ""),
    }
    with open(chemin_sortie[:-5] + ".json", "w", encoding="utf-8") as f:
        json.dump(donnees, f, ensure_ascii=False, indent=2)

    if args.enregistrer:
        if numero_auto:
            d = config.setdefault("devis", {})
            fmt = d.get("format_numero", "{prefixe}-{annee}-{seq:03d}")
            if "{annee}" in fmt and d.get("reset_annuel", True) and \
               d.get("annee_serie") is not None and int(d["annee_serie"]) != date_emission.year:
                d["prochain_numero"] = 2  # le 001 vient d'être émis
            else:
                d["prochain_numero"] = int(d.get("prochain_numero", 1)) + 1
            d["annee_serie"] = date_emission.year
            with open(args.config, "w", encoding="utf-8") as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
        carnet_chemin = os.path.join(os.path.dirname(os.path.abspath(args.config)), "clients.json")
        carnet = {"clients": []}
        if os.path.exists(carnet_chemin):
            with open(carnet_chemin, encoding="utf-8") as f:
                carnet = json.load(f)
        c = devis["client"]
        deja = next((x for x in carnet["clients"]
                     if x["nom"].strip().lower() == c["nom"].strip().lower()), None)
        if deja:
            deja.update(c)
        else:
            carnet["clients"].append(c)
        with open(carnet_chemin, "w", encoding="utf-8") as f:
            json.dump(carnet, f, ensure_ascii=False, indent=2)

        # Catalogue des prestations : même mécanisme que le carnet clients.
        # Chaque ligne générée est mémorisée (référence, désignation, détails,
        # unité, prix, taux) pour être PROPOSÉE la prochaine fois, jamais
        # appliquée en silence. Une ligne redonnée avec un nouveau prix met
        # sa fiche à jour.
        cat_chemin = os.path.join(os.path.dirname(os.path.abspath(args.config)), "catalogue.json")
        catalogue = {"prestations": []}
        if os.path.exists(cat_chemin):
            with open(cat_chemin, encoding="utf-8") as f:
                catalogue = json.load(f)

        def meme_fiche(fiche, ligne):
            if fiche.get("reference") and ligne.get("reference"):
                return fiche["reference"].strip().lower() == ligne["reference"].strip().lower()
            return fiche["designation"].strip().lower() == ligne["description"].strip().lower()

        for l in calc["lignes"]:
            fiche = {"reference": l.get("reference"), "designation": l["description"],
                     "details": l.get("details", ""), "unite": l.get("unite", ""),
                     "prix_unitaire_ht": l["prix_unitaire_ht"], "taux_tva": l["taux_tva"]}
            deja = next((x for x in catalogue["prestations"] if meme_fiche(x, l)), None)
            if deja:
                deja.update(fiche)
            else:
                catalogue["prestations"].append(fiche)
        with open(cat_chemin, "w", encoding="utf-8") as f:
            json.dump(catalogue, f, ensure_ascii=False, indent=2)

    recap = {
        "fichier": chemin_sortie,
        "numero": numero,
        "date": date_fr(date_emission),
        "valable_jusquau": date_fr(date_validite),
        "total_ht": montant_fr(calc["total_ht"]),
        "total_tva": montant_fr(calc["total_tva"]) if not calc["franchise"] else "franchise de TVA",
        "total_ttc": montant_fr(calc["total_ttc"]),
        "compteur_mis_a_jour": bool(args.enregistrer and numero_auto),
    }
    print(json.dumps(recap, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
