---
name: generer-devis
description: >-
  Génère des devis professionnels français, conformes et numérotés, prêts à
  imprimer en PDF. Utiliser dès que l'utilisateur veut faire, créer, préparer,
  refaire, corriger ou envoyer un devis, chiffrer une prestation pour un
  client, donner un prix par écrit, ou dit simplement « devis pour [client] »,
  même sans détail. Utiliser aussi quand il veut modifier ses informations
  d'entreprise pour ses devis (adresse, logo, assurance, numérotation, TVA).
  À la première utilisation, dérouler le setup guidé qui enregistre une fois
  pour toutes les informations de l'entreprise ; ensuite, chaque devis ne
  demande que le client, la prestation et le prix.
---

# Générer un devis

Ce skill transforme une demande en une phrase (« devis pour Mme Martin,
remplacement du chauffe-eau, 980 € ») en un devis professionnel conforme au
droit français : mentions obligatoires, numérotation qui se suit, TVA ou
franchise, prêt à imprimer en PDF.

L'utilisateur est souvent non-technique et découvre peut-être l'IA. Parle-lui
simplement, sans jargon (jamais « JSON », « script », « configuration » : dire
« tes informations enregistrées »). Pose une question à la fois.

## Les trois règles qui ne se négocient pas

1. **Rien ne s'invente.** Un SIRET, une adresse, un prix, un taux de TVA, un
   assureur : si l'information manque, elle se demande. Un devis avec une
   donnée inventée est un faux document ; mieux vaut une question de plus.
2. **Tous les calculs et tout le rendu passent par le script**
   `scripts/generer_devis.py`. Ne calcule jamais un total toi-même, ne
   fabrique jamais le HTML à la main : le script est la seule source de
   vérité (totaux, TVA, formats de montants, mentions conditionnelles).
3. **Récapituler avant de générer.** Avant d'appeler le script, montre en
   2-3 lignes ce qui va figurer sur le devis (client, lignes avec prix,
   total). Une erreur corrigée avant génération coûte une phrase ; après,
   c'est un devis faux envoyé à un client.

## Étape 0, à chaque invocation : la configuration existe-t-elle ?

Cherche le fichier de configuration, dans cet ordre :

1. `config/entreprise.json` dans le dossier de ce skill ;
2. `entreprise-devis.json` dans le dossier de travail courant (cas où le
   dossier du skill n'est pas accessible en écriture).

- **Le fichier existe** : lis-le (et `clients.json` à côté s'il existe), puis
  va directement à « Faire un devis ». Ne redemande JAMAIS une information
  qui s'y trouve déjà : c'est la promesse centrale du skill.
- **Le fichier n'existe pas** : c'est la première utilisation, déroule le
  setup ci-dessous avant toute chose.

## Le setup de première utilisation (une seule fois, ~10 minutes)

Objectif : collecter tout ce qui est stable d'un devis à l'autre, l'écrire
dans la configuration, et ne plus jamais le redemander.

**Annonce d'abord la couleur**, en une phrase : « Première utilisation : je te
pose une dizaine de questions sur ton entreprise (une seule fois), garde sous
la main ton numéro SIRET et, si tu es dans le bâtiment, le nom de ton
assureur. Ça prend une dizaine de minutes, ensuite chaque devis prendra deux
minutes. »

Puis pose les questions **bloc par bloc, une question à la fois**, dans cet
ordre (le pourquoi de chaque bloc est dans
`references/mentions-obligatoires.md`, à consulter en cas de doute ou de
question de l'utilisateur ; ne jamais improviser une réponse juridique) :

1. **L'entreprise** : nom ; forme (auto-entrepreneur, aussi appelé
   micro-entrepreneur : c'est la même chose, utiliser le mot que
   l'utilisateur emploie / entreprise individuelle / société type SARL,
   SAS…) ; adresse ; SIRET (14 chiffres, sur l'avis INSEE ou l'extrait
   Kbis). Si entreprise individuelle ou auto-entrepreneur : la mention
   « EI » est obligatoire, active-la sans poser la question. Si société :
   demander capital social et ville du RCS (sur le Kbis).
2. **La TVA** : factures-tu la TVA ? Un auto-entrepreneur qui ne la facture
   pas est « en franchise » : le devis portera automatiquement la mention
   « TVA non applicable, art. 293 B du CGI » et aucun montant de TVA. Sinon,
   demander le taux habituel (20 % en général ; 10 % ou 5,5 % dans le
   bâtiment selon les travaux), le numéro de TVA intracommunautaire s'il
   figure sur ses factures, ET sa convention de prix : « quand tu
   m'annonceras un prix sans préciser, je le prends en HT ou en TTC ? »
   (clé `prix_annonces` : « ht », « ttc » ou « demander »). Les pros entre
   eux parlent souvent HT, ceux qui servent des particuliers pensent
   souvent TTC : c'est à lui de choisir, pas à toi de deviner. En
   franchise, la question ne se pose jamais : pas de TVA, le prix est le
   prix.
3. **Le métier** : que fait l'entreprise ? Si activité du bâtiment ou
   artisanale avec assurance obligatoire (décennale) : nom de l'assureur,
   ses coordonnées, la couverture géographique. C'est une mention légale
   obligatoire sur les devis d'artisans, pas une option.
4. **Les habitudes de devis** : durée de validité (30 jours si aucune
   préférence) ; acompte demandé habituellement ; conditions de règlement ;
   IBAN à afficher (optionnel) ; format de numérotation. Par défaut la
   numérotation est DEV-ANNÉE-001 et se poursuit toute seule ; si
   l'utilisateur a déjà des devis, demander son dernier numéro TEL QU'IL
   L'ÉCRIT et reprendre son format à l'identique, préfixe compris (jamais
   plaquer le format par défaut sur sa série existante), puis confirmer le
   prochain numéro qui sera émis. Le passage d'année est géré par le
   script (format avec année = la séquence repart à 1 au 1er janvier ;
   `reset_annuel` à false pour une numérotation continue).
5. **Les optionnels** : téléphone, email, site web, logo (un fichier image ;
   le copier dans le dossier de configuration) ; pour ceux qui travaillent
   avec des particuliers, le médiateur de la consommation. Ce mot est du
   jargon pour un débutant : l'expliquer avec ces mots simples, « un
   organisme gratuit de règlement des litiges avec les clients
   particuliers ; on y adhère souvent par sa fédération professionnelle ;
   si tu en as un je l'affiche, si tu ne sais pas on passe ». Proposer,
   ne pas imposer.
6. **Les champs libres** : demander s'il veut voir apparaître autre chose
   sur tous ses devis (certification RGE, label, mention spéciale…), et OÙ :
   sous ses coordonnées (`champs_libres`, bloc entreprise) ou en bas du
   devis (`mentions_libres`). Un champ libre peut être une simple ligne de
   texte (« Membre des Artisans… ») ou un couple étiquette + valeur : les
   deux formes marchent. L'utilisateur ne doit jamais renoncer à un champ
   dont il a besoin.

Écris ensuite la configuration (modèle : `references/exemple-config.json`),
montre un récapitulatif en clair, et propose un devis d'essai immédiat avec
un client fictif pour valider la mise en page (logo, mentions).

**Mise à jour** : « j'ai changé d'adresse », « nouveau logo », « je facture
la TVA maintenant » : modifier la ou les clés concernées, confirmer, et ne
surtout pas redérouler tout le setup.

## Faire un devis (usage courant : 2-3 questions maximum)

1. **Le client.** Si le nom donné correspond à un client de `clients.json`
   (même approximativement), utiliser sa fiche et le dire (« Mme Martin, 8
   avenue du Parc à Lyon, comme la dernière fois »). Si c'est un NOUVEAU
   client, collecter sa fiche complète en une fois : nom, adresse
   obligatoirement ; téléphone, email, et SIRET si c'est une entreprise
   (proposés, pas imposés). Elle est mémorisée au carnet : c'est la
   dernière fois qu'on la demande.
2. **La prestation et le prix.** AVANT de demander quoi que ce soit,
   regarder le CATALOGUE (`catalogue.json` à côté du carnet clients, rempli
   automatiquement à chaque devis) : si la désignation ou la référence
   donnée par l'utilisateur correspond à une fiche mémorisée, la PROPOSER
   (« le radiateur X400, réf. 4521, 890 € HT comme la dernière fois ? »)
   au lieu de redemander prix, détails ou unité. La mémoire propose,
   l'utilisateur décide : jamais un prix mémorisé appliqué sans qu'il ait
   confirmé, et s'il donne un nouveau prix ou de nouveaux détails, c'est sa
   parole qui fait foi (le script met la fiche à jour tout seul). Sinon :
   description de chaque ligne, prix HT, quantité si pertinent, et la
   référence produit si l'utilisateur en utilise (champ `reference`,
   affichée sur le devis). La désignation est la partie que le client final
   lira : viser une ligne claire et professionnelle (l'objet précis, la
   référence ou le modèle s'il y en a, le détail en dessous via le champ
   `details`), mais c'est L'UTILISATEUR qui choisit le niveau de détail :
   proposer d'enrichir (« tu veux que j'ajoute la référence ou une ligne de
   détail ? »), jamais imposer ni inventer un détail technique.

   **Un prix annoncé est ambigu tant qu'on ne sait pas s'il est HT ou
   TTC**, et l'écart n'est pas un détail (1 200 € HT, c'est 1 440 € TTC).
   La règle : en franchise de TVA, aucune ambiguïté, le prix est le prix.
   Avec TVA : si l'utilisateur a dit « TTC », « tout compris » ou « HT »,
   c'est réglé ; sinon appliquer sa convention enregistrée au setup
   (`prix_annonces`) ; et si elle est sur « demander » (ou absente), poser
   LA question courte : « 1 200 €, c'est hors taxes ou TTC ? ». Ne jamais
   déduire en silence. Pour un prix TTC, passer `prix_unitaire_ttc` au
   script : c'est LUI qui convertit (jamais de division de tête), et le
   récapitulatif montre toujours HT, TVA et TTC pour que tout malentendu
   saute aux yeux avant génération. Pour les travaux : lieu
   d'exécution, date de début et durée estimée si connus (mentions
   attendues sur un devis de travaux). Pour une prestation à date butoir
   (« pour le 20 août »), utiliser le champ `echeance` (affiché « À
   réaliser pour le »), pas `date_debut`. Si l'échéance dépasse la date de
   validité du devis, préciser à l'utilisateur que la validité concerne la
   signature du devis, pas la livraison : les deux peuvent coexister.
3. **Rien d'autre**, sauf particularité du jour : acompte différent,
   mention spéciale, ou REMISE. Les remises passent par les champs prévus
   (jamais un prix discrètement baissé ni une ligne négative) :
   `remise_pct` ou `remise_montant` sur une ligne, ou le bloc `remise` du
   devis (`{"libelle": "Remise de lancement", "pourcentage": 10}` ou
   `montant_ht`) affiché dans les totaux ; la TVA est calculée par le
   script sur le net après remise. Une remise habituelle mémorisée dans la
   fiche client se propose, ne s'applique jamais seule. Tout le reste
   vient de la configuration.

**Le devis type (« comme d'habitude »)** : pour un devis qui ressemble à un
ancien, repartir du fichier de données d'un devis précédent (le `.json` à
côté du HTML dans `Devis/`), garder les lignes, ajuster ce qui change, et
laisser la numérotation avancer. La fiche d'un client peut aussi porter ses
particularités durables (adresse de chantier habituelle, remise fidélité) :
les proposer au bon moment, jamais les imposer.

Puis :

- construis le fichier de devis (modèle : `references/exemple-devis.json`)
  dans un dossier temporaire ;
- montre le récapitulatif (règle 3) et attends l'accord ;
- appelle le script :

  ```bash
  python3 <dossier-du-skill>/scripts/generer_devis.py \
    --config <chemin-de-la-config> --devis <fichier-du-jour> \
    --sortie Devis --enregistrer
  ```

  `--enregistrer` fait avancer la numérotation et mémorise le client pour la
  prochaine fois. Ne l'omettre que pour un essai ou une reprise d'un devis
  déjà généré (dans ce cas, passer aussi son numéro dans le devis).
- Le script affiche le chemin du fichier et les totaux. Si le script signale
  une information manquante, pose la question à l'utilisateur et relance :
  ne comble jamais le trou toi-même.

**Livraison** : ouvre le fichier pour l'utilisateur quand c'est possible
(`open` sur Mac, `start` sur Windows), dis-lui en clair où il se trouve
(dossier `Devis/`, avec le chemin complet), et rappelle en une phrase
comment en faire un PDF : imprimer (Cmd+P sur Mac, Ctrl+P sur Windows) puis
« Enregistrer au format PDF ». Le bandeau gris d'aide en haut du fichier
disparaît à l'impression. Propose de vérifier le devis ensemble si c'est le
premier. Ne montre jamais la sortie brute du script (le JSON) : traduis le
récapitulatif en français courant.

La partie variable est LE cœur d'usage du skill : la rendre la plus courte
possible tout en captant le maximum d'informations. Encourager l'utilisateur
à tout donner en une seule phrase ou un seul message (client, lignes, prix,
particularités) et ne poser de questions que pour ce qui manque vraiment ;
ne jamais transformer un devis en interrogatoire.

## Plusieurs devis d'un coup (mode rafale)

Quand l'utilisateur annonce plusieurs devis (« j'ai 5 devis à faire »),
basculer en mode rafale :

1. Collecter d'abord TOUTES les variables, devis par devis, dans un seul
   échange structuré : pour chacun, le client (fiche complète si nouveau,
   juste le nom s'il est au carnet), les lignes avec prix, les
   particularités. Accepter la liste en vrac dans un seul message, c'est le
   but : l'utilisateur remplit tout en une passe de quelques minutes.
2. Montrer UN récapitulatif groupé (un devis par ligne : client, objet,
   total estimé) et attendre un seul accord.
3. Générer les devis en série avec le script, chacun avec `--enregistrer` :
   la numérotation avance automatiquement d'un devis à l'autre, chaque
   nouveau client entre au carnet.
4. Livrer la liste complète des fichiers d'un coup, avec le rappel PDF une
   seule fois.

L'intérêt pour l'utilisateur : dix minutes de réponses, puis il passe à
autre chose pendant que les devis sortent. Ne jamais entrelacer les
questions de plusieurs devis : toutes les questions d'abord, toute la
génération ensuite.

## Modifier ou refaire un devis

Pour corriger un devis déjà généré (prix, ligne, faute) : reprendre son
fichier de devis, appliquer la modification, regénérer avec le MÊME numéro
(champ `numero`, sans `--enregistrer`). Pour un nouveau devis qui ressemble à
un ancien : repartir de l'ancien fichier mais laisser la numérotation
avancer normalement (avec `--enregistrer`).

## Ce que ce skill ne fait pas

Pas de factures, pas de relances, pas de signature électronique, pas de
conseil juridique ou fiscal personnalisé. Pas non plus les secteurs à devis
NORMALISÉ imposé par un modèle réglementaire (optique, audioprothèse,
funéraire) : si l'utilisateur en relève, le prévenir honnêtement que ce
skill ne remplace pas son formulaire réglementaire. Si l'utilisateur a une question de
droit précise (seuils de TVA, obligation sectorielle), consulter
`references/mentions-obligatoires.md` qui cite les sources officielles
(service-public.gouv.fr, economie.gouv.fr) et l'y renvoyer ; en cas de doute
qui persiste, le dire honnêtement plutôt que de trancher.
