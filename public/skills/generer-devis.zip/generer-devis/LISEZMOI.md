# Générer un devis : le mode d'emploi

Ce skill fait tes devis à ta place. Tu lui dis « devis pour Madame Martin,
remplacement du chauffe-eau, 980 euros », et il te sort un devis
professionnel, avec toutes les mentions légales françaises, un numéro qui se
suit tout seul, et ta TVA (ou ta franchise) gérée correctement. Compte 2 à 3
minutes par devis, contre 20 à 40 minutes en bricolant un ancien fichier
Word.

Il est fait pour les indépendants et les petites entreprises françaises :
artisans, consultants, agences, auto-entrepreneurs.

## Ce qu'il te faut (honnêtement)

- Un abonnement Claude payant : la version gratuite ne suffit pas,
  l'abonnement Pro (environ 20 € par mois) suffit. Si un jour tu fais
  tellement de devis que tu touches les limites du Pro, le plan au-dessus
  existe, mais commence avec Pro et vois si le service te fait gagner
  assez de temps pour en vouloir plus.
- L'application Claude qui lit les skills et peut travailler dans un
  dossier : Claude Code, ou l'application de bureau Claude (Mac ou
  Windows). C'est là que ta configuration reste enregistrée d'une fois sur
  l'autre.
- Rien d'autre. Aucun logiciel à installer, aucun abonnement en plus. Le
  devis sort en fichier HTML que tu transformes en PDF en l'imprimant
  (l'ordinateur te propose « Enregistrer au format PDF » : c'est tout).

## Les trois gestes

**Geste 1 : installe le skill.** Le plus simple : tu n'installes rien
toi-même, tu demandes à Claude de le faire. Ouvre Claude et écris :
« installe le skill generer-devis qui est dans mon dossier Téléchargements »
(ou l'endroit où tu as mis le dossier téléchargé). Il le range au bon
endroit et te confirme.
Si tu préfères le faire à la main dans l'application de bureau : Réglages,
puis Capacités, puis Skills, et importe le fichier téléchargé.

**Geste 2 : la première fois, laisse-le faire connaissance.** Écris
simplement « fais-moi un devis ». Le skill voit qu'il ne te connaît pas
encore et te pose une dizaine de questions, une par une : ton entreprise,
ton adresse, ton SIRET, ta TVA, ton assurance si tu es dans le bâtiment,
tes habitudes (validité, acompte). Garde ton SIRET sous la main. Ça prend
une dizaine de minutes, UNE SEULE FOIS. Tout est enregistré : il ne te le
redemandera plus jamais.

**Geste 3 : fais tes devis.** À partir de là, chaque devis c'est une
phrase : « Devis pour [le client] : [la prestation], [le prix] ». Il te
montre un récapitulatif, tu dis oui, et le fichier est prêt. Tes clients
habituels sont mémorisés : « même client que la dernière fois » suffit.
Et si tu as plusieurs devis à sortir, donne-les tous d'un coup (« j'ai 5
devis à faire, voici tout ») : tu réponds une fois, tu valides une fois,
les 5 fichiers sortent en série pendant que tu fais autre chose.

## Et si quelque chose change

Dis-le comme tu le dirais à un collègue : « j'ai changé d'adresse », « j'ai
un nouveau logo », « je facture la TVA maintenant ». Il met à jour juste ce
qui a changé, sans tout te redemander. Tu peux aussi lui demander d'ajouter
un champ à toi sur tes devis (une certification, un label, une mention
spéciale) : il le gardera pour tous les suivants.

## Ce qu'il ne fait pas

Les factures, les relances et la signature électronique, ce n'est pas lui.
Il ne donne pas non plus de conseil juridique : il applique les règles
officielles (service-public.gouv.fr, economie.gouv.fr), les sources sont
listées dans le dossier `references`. Si ton métier impose un devis sur
formulaire réglementaire (optique, audioprothèse, funéraire), ce skill ne
remplace pas ce formulaire.

---

Offert par The Vibe Company (thevibecompany.co). Libre d'utilisation, sans
support garanti.
