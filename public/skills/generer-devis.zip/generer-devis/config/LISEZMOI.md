# Dossier de configuration

Ce dossier est vide à l'installation : il se remplit tout seul à ta
première utilisation du skill.

- `entreprise.json` : les informations de ton entreprise, collectées une
  fois lors du setup (identité, TVA, assurance, habitudes de devis,
  numérotation). C'est lui qui évite que le skill te repose les mêmes
  questions à chaque devis.
- `clients.json` : ton carnet de clients, enrichi automatiquement à chaque
  devis pour ne jamais retaper une adresse.
- `catalogue.json` : la mémoire de tes prestations et produits (référence,
  désignation, prix, TVA), enrichie automatiquement. La prochaine fois que
  tu vends la même chose, le skill te propose la fiche au lieu de tout
  redemander ; c'est toujours toi qui confirmes le prix.
- Ton logo, si tu en as donné un au setup.

Pour modifier quelque chose, ne touche pas à ces fichiers : dis simplement
au skill « j'ai changé d'adresse » (ou autre), il s'en occupe.
