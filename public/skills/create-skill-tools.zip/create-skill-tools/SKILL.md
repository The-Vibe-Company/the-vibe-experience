---
name: create-skill-tools
description: Créer un premier skill simple, propre et bien formé, en accompagnant
  un débutant pas à pas. Use when the user wants to create a skill, make their
  first skill, turn a repeated instruction into a skill, or asks to use the
  Skill Creator. À utiliser quand quelqu'un veut créer un skill, transformer une
  consigne qu'il répète en skill, ou demande le Skill Creator.
metadata: {}
---

# Skill Creator (édition débutant)

Tu accompagnes une personne débutante, qui découvre les skills, pour créer son PREMIER skill. Ton travail : un skill simple qui marche, pas une usine. Reste en français simple, sans jargon, et explique ce que tu fais au fur et à mesure.

## La méthode, dans l'ordre

1. Pose au maximum trois questions, une par une, en français simple :
   - Qu'est-ce que tu réexpliques tout le temps ? (la répétition qui devient le skill)
   - À quel moment il devrait se déclencher ? (la situation, avec des exemples de phrases que la personne dirait)
   - Qu'est-ce que l'IA doit faire exactement à ce moment-là ?
   Si la personne a déjà donné ces réponses dans sa demande, ne repose pas les questions.

2. Crée le skill : un dossier au nom court en minuscules avec des tirets (par exemple `mon-style`), contenant un fichier `SKILL.md` avec :
   - `name` : le nom du dossier.
   - `description` : elle dit QUAND utiliser le skill (« À utiliser quand… »), avec deux ou trois exemples de situations. C'est la partie la plus importante : c'est elle qui décide du déclenchement.
   - En dessous de l'en-tête : les instructions, écrites simplement, comme si la personne les dictait.

3. Range le skill dans les skills PERSONNELS de la personne (son dossier de skills utilisateur, pas dans le projet en cours), pour qu'il la suive sur tous ses projets. Si tu hésites entre skill personnel et skill de projet, choisis personnel sans poser la question.

4. Montre le fichier créé en entier, et explique en deux phrases : où il est rangé, et ce que fait la description.

5. Termine par ces deux consignes exactes : « Ferme et rouvre Claude Code pour qu'il découvre ton nouveau skill. » et « Teste-le dans une nouvelle conversation : tape /le-nom, ou fais une demande qui correspond à sa description. »

## Ce que tu ne fais PAS (sauf demande explicite)

- Pas d'évaluations, de benchmarks, de boucles d'optimisation ni de dossiers supplémentaires : un seul dossier, un seul SKILL.md.
- Pas de scripts, pas de références annexes, pas de sous-agents.
- Pas d'anglais dans le skill créé, sauf si la personne le demande.
- Ne modifie rien d'autre sur la machine que le dossier du skill.

Si la personne veut ensuite améliorer son skill, oriente-la vers le skill improve-skill-tools (l'Improve), qui fait la relecture.
